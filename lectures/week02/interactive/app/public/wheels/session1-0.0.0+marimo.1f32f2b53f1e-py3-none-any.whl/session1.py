"""S01–S06: one dataset, sequenced controls, and linked mathematical views.

Renderers propose events; the course shell alone commits state and navigates.
Control buttons cycle small authored presets so each click is a visible experiment.
"""
from dataclasses import dataclass
from html import escape
from itertools import combinations

import numpy as np

from course_player import SceneResult, StateEvent
from public.model import design_matrix, loss_rho_psi
import visuals

BASE_X = (-2., -1.4, -.8, -.2, .4, 1., 1.6, 2.2)
BASE_Y = tuple(1 + 1.35 * x + noise for x, noise in zip(BASE_X, (.15, -.18, .08, -.12, .12, -.08, .18, -.1)))
SHARED_PRESET = {"s1.x": BASE_X, "s1.y": BASE_Y, "s1.w0": 0., "s1.w1": .5, "s1.outlier": 0.}
LOCAL_PRESET = {"selected": 7, "delta": 1., "case": "contamination"}

ANNOTATIONS = {
    "L02-S01-rule": r"$\hat y_i=f_w(x_i)=w_0+w_1x_i$: the same rule predicts every point, including unseen inputs.",
    "L02-S02-intercept": r"$\Delta\hat y_i=\Delta w_0$, hence $\Delta r_i=-\Delta w_0$: every prediction moves equally.",
    "L02-S02-slope": r"$\Delta\hat y_i=x_i\Delta w_1$, hence $\Delta r_i=-x_i\Delta w_1$: opposite signs of $x_i$ move oppositely.",
    "L02-S03-residual": r"$r_i=y_i-\hat y_i$ is the signed vertical gap; $r=y-Xw\in\mathbb R^8$, with $X=[\mathbf1,x]$.",
    "L02-S04-objective": r"$J(w)=\frac1{2N}\sum_i r_i^2=\frac1{2N}\|r\|_2^2$, $N=8$. Each bar contributes $r_i^2/16$; signs cannot cancel.",
    "L02-S05-loss": r"$J_\rho(w)=\frac1N\sum_i\rho(r_i)$. Half-MSE: $\rho(r)=r^2/2$; MAE: $\rho(r)=|r|$. Compare fitted lines, not differently scaled objective values.",
    "L02-S05-influence": r"$\psi(r)=\rho'(r)$: half-MSE uses $r$; MAE uses $\operatorname{sign}(r)$ away from zero. At zero its subgradient is $[-1,1]$; we display $\psi(0)=0$.",
    "L02-S05-huber": r"Huber: $\rho_\delta(r)=r^2/2$ for $|r|\leq\delta$, else $\delta(|r|-\delta/2)$; $\psi_\delta(r)=\operatorname{clip}(r,-\delta,\delta)$.",
    "L02-S05-boundary": r"At $r=\pm\delta$, both pieces give $\delta^2/2$ and slopes $\pm\delta$: Huber is continuously differentiable. Its second derivative jumps there.",
    "L02-S05-gradient": r"$\nabla_w J_\rho=-\frac1N\sum_i x_i^{\rm aug}\psi(r_i)$, $x_i^{\rm aug}=(1,x_i)^T$. Bounded residual influence does not protect against arbitrarily large feature leverage.",
    "L02-S06-choice": r"Choose a loss using the noise mechanism and the cost of errors. Squared loss matches Gaussian noise; absolute loss matches Laplace noise; Huber limits residual influence under response contamination.",
}

TRANSFER_CASES = {
    "contamination": {
        "prompt": "A sensor usually has small symmetric errors, but 1 in 20 readings is corrupted upward. Which loss would you defend, and what would you check?",
        "answer": "Huber is a defensible compromise: quadratic near zero, bounded residual influence for corrupted responses. Choose delta using the ordinary noise scale; check residuals and feature leverage. MAE is also defensible when stronger robustness outweighs smoothness.",
    },
    "gaussian": {
        "prompt": "Repeated calibrated measurements have independent Gaussian errors with constant variance, and large errors are especially costly. Which loss is natural?",
        "answer": "Use squared loss: with a correct mean model and independent constant-variance Gaussian noise, minimizing squared residuals is maximum likelihood. The factor one-half changes gradients' scale, not the minimizer.",
    },
    "laplace": {
        "prompt": "Calibration errors follow a symmetric Laplace distribution, and evaluation charges the same amount per unit absolute error. Which loss is natural?",
        "answer": "Use absolute loss: it matches Laplace maximum likelihood and the stated absolute-error cost. The target is a conditional median; at zero use a subgradient rather than claiming a unique derivative.",
    },
}


@dataclass(frozen=True)
class Control:
    key: str
    label: str
    values: tuple
    math_refs: tuple[str, ...]


W0 = Control("s1.w0", "intercept w0", (0., 1., 2.), ("L02-S02-intercept",))
W1 = Control("s1.w1", "slope w1", (.5, 1., 1.5), ("L02-S02-slope",))
POINT = Control("selected", "highlight point i", (7, 0, 3), ("L02-S03-residual",))
OUTLIER = Control("s1.outlier", "response contamination", (0., 2., 4., 8.), ("L02-S05-loss", "L02-S05-influence"))
DELTA = Control("delta", "Huber delta", (1., .25, 3.), ("L02-S05-huber",))
CONTROLS = {
    "L02-S01": (Control("s1.w0", "rule intercept w0", (0., 1., 2.), ("L02-S01-rule",)),),
    "L02-S02": (W0, W1),
    "L02-S03": (Control(W0.key, W0.label, W0.values, ("L02-S03-residual",)), POINT),
    "L02-S04": (Control(W0.key, W0.label, W0.values, ("L02-S04-objective",)), Control(POINT.key, POINT.label, POINT.values, ("L02-S04-objective",))),
    "L02-S05": (OUTLIER, DELTA, Control(POINT.key, POINT.label, POINT.values, ("L02-S05-loss",))),
    "L02-S06": (Control("case", "new noise situation", tuple(TRANSFER_CASES), ("L02-S06-choice",)), Control(OUTLIER.key, OUTLIER.label, OUTLIER.values, ("L02-S06-choice",))),
}


def validate_scene_contract(scene, *, controls=None):
    for layer in scene.layers:
        for ref in layer.math_refs:
            if ref not in ANNOTATIONS:
                raise ValueError(f"{scene.scene_id}: undeclared math annotation {ref}")
    for control in CONTROLS[scene.scene_id] if controls is None else controls:
        if control.key not in scene.state_ownership:
            raise ValueError(f"{scene.scene_id}: undeclared control key {control.key}")
        if not control.math_refs or any(ref not in scene.slide_claims or ref not in ANNOTATIONS for ref in control.math_refs):
            raise ValueError(f"{scene.scene_id}: undeclared math reference for control {control.key}")


@dataclass(frozen=True)
class Fit:
    weights: np.ndarray
    rho: np.ndarray
    psi: np.ndarray
    point_residual: float
    point_contribution: float


@dataclass(frozen=True)
class SceneData:
    x: np.ndarray
    y: np.ndarray
    design: np.ndarray
    weights: np.ndarray
    prediction: np.ndarray
    residual: np.ndarray
    contributions: np.ndarray
    objective: float
    selected: int
    delta: float
    fits: dict[str, Fit]
    outlier: float


def _fit_weights(X, y, kind, delta):
    """Exact LS/LAD and converged convex Huber IRLS for the eight-point demo."""
    w = np.linalg.lstsq(X, y, rcond=None)[0]
    if kind == "mse":
        return w
    if kind == "mae":
        # A two-parameter LAD optimum has a vertex through two observations.
        candidates = [np.linalg.solve(X[list(pair)], y[list(pair)]) for pair in combinations(range(len(y)), 2)]
        return min(candidates, key=lambda weights: np.abs(y - X @ weights).sum())
    for _ in range(2000):
        residual = y - X @ w
        weights = np.minimum(1., delta / np.maximum(np.abs(residual), np.finfo(float).eps))
        root = np.sqrt(weights)
        w = np.linalg.lstsq(X * root[:, None], y * root, rcond=None)[0]
        if np.max(np.abs(X.T @ np.clip(y - X @ w, -delta, delta) / len(y))) < 1e-9:
            return w
    raise RuntimeError("Huber fit did not converge; use the static fallback")


def scene_data(state):
    """Validate all mathematical inputs before deriving any linked view."""
    def invalid(detail):
        raise ValueError(f"{state.scene_id}: {detail}")
    if set(state.shared_state) != set(SHARED_PRESET) or set(state.scene_state) != set(LOCAL_PRESET):
        invalid("missing or undeclared mathematical/control key")
    shared, local = state.shared_state, state.scene_state
    try:
        x, y = np.asarray(shared["s1.x"], dtype=float), np.array(shared["s1.y"], dtype=float)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{state.scene_id}: dataset must contain numeric values") from exc
    if x.shape != (8,) or y.shape != (8,) or not np.isfinite(x).all() or not np.isfinite(y).all() or len(np.unique(x)) != 8:
        invalid("expected eight finite observations with distinct x values")
    for key in ("s1.w0", "s1.w1", "s1.outlier"):
        value = shared[key]
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not np.isfinite(value) or abs(value) > 100:
            invalid(f"{key} must be finite and within [-100,100]")
    delta, selected = local["delta"], local["selected"]
    if isinstance(delta, bool) or not isinstance(delta, (int, float)) or not np.isfinite(delta) or not .01 <= delta <= 100:
        invalid("delta must be finite and in [0.01,100]")
    if isinstance(selected, bool) or not isinstance(selected, int) or not 0 <= selected < 8:
        invalid("selected must be an integer point index in [0,7]")
    if local["case"] not in TRANSFER_CASES:
        invalid("unknown transfer case")
    y[-1] += shared["s1.outlier"]
    X = design_matrix(x)
    w = np.array([shared["s1.w0"], shared["s1.w1"]])
    prediction = X @ w
    residual = y - prediction
    contributions = residual**2 / 16
    fits = {}
    if state.scene_id in ("L02-S05", "L02-S06"):
        for kind in ("mse", "mae", "huber"):
            weights = _fit_weights(X, y, kind, delta)
            fit_r = y - X @ weights
            rho, psi = loss_rho_psi(fit_r, kind=kind, delta=delta)
            fits[kind] = Fit(weights, rho, psi, float(fit_r[selected]), float(rho[selected] / 8))
    return SceneData(x, y, X, w, prediction, residual, contributions, float(contributions.sum()), selected, delta, fits, shared["s1.outlier"])


def render_scene(state):
    import marimo as mo
    # Deferred to avoid a manifest/renderer import cycle and keep lazy rendering.
    from manifest import MANIFEST
    scene = next(scene for scene in MANIFEST.scenes if scene.scene_id == state.scene_id)
    validate_scene_contract(scene)
    layer = next(layer for layer in scene.layers if layer.layer_id == state.layer_id)
    data = scene_data(state)
    figure = visuals.scene_figure(state.scene_id, data, stage=layer.stage)
    body = [mo.Html(f'<article data-scene="{escape(state.scene_id)}" data-visual-stage="{escape(layer.stage)}" data-render-sequence="{state.sequence}"></article>'), mo.Html(visuals.figure_svg(figure))]
    events = []
    control_summaries = []
    visible_refs = []
    if layer.stage != "predict":
        for control in CONTROLS[state.scene_id]:
            values = state.shared_state if control.key in state.shared_state else state.scene_state
            current = values[control.key]
            index = control.values.index(current) if current in control.values else -1
            following = control.values[(index + 1) % len(control.values)]
            display_current = current + 1 if control.key == "selected" else current
            display_following = following + 1 if control.key == "selected" else following
            control_summaries.append(mo.md(f"**{control.label}:** {display_current} → {display_following} on Apply `{control.key}`."))
            if layer.stage in ("explain", "transfer"):
                visible_refs.extend(control.math_refs)
            # UI intents are sequenced by the controller when actually clicked.
            events.append(StateEvent("write", scene_id=state.scene_id, key=control.key, value=following, label=control.label))
        body.append(mo.hstack(control_summaries, wrap=True))
    if layer.stage in ("explain", "transfer"):
        visible_refs.extend(layer.math_refs)
    if visible_refs:
        body.append(mo.md("\n\n".join(ANNOTATIONS[ref] for ref in dict.fromkeys(visible_refs))))
    if state.scene_id == "L02-S06":
        case = TRANSFER_CASES[state.scene_state["case"]]
        body.append(mo.md(case["prompt"]))
        if state.answer_visible:
            body.append(mo.callout(mo.md(case["answer"]), kind="info"))
    return SceneResult(mo.vstack(body), tuple(events))
