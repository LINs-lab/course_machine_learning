"""S13–S18: stationarity, projection, identifiable predictions and solver choice.

Three observations let us inspect the entire design. Collinearity is scene-local:
the exact-deficiency experiment must not inherit S14's full-rank setting.
"""
from dataclasses import dataclass, replace
from html import escape
from textwrap import fill

import numpy as np
from matplotlib.figure import Figure

from course_player import SceneResult, StateEvent
from public.model import (gd_path, gradient_mse, least_squares_summary,
                          null_space_family, objective, projection_summary)
from session1 import Control
from visuals import COLORS, figure_svg

SHARED_PRESET = {"s3.y": (1., 2., .5)}


def scene_presets(sid):
    return dict(SHARED_PRESET), {
        "collinearity": 0. if sid in ("L02-S15", "L02-S16") else (1e-5 if sid == "L02-S17" else 1.),
        "solution": 0. if sid == "L02-S13" else 1., "null_step": 0.,
        "null_vector": None, "initialization": "zero", "case": "duplicate",
    }


ANNOTATIONS = {
    "L02-S13-stationarity": r"$e=y-Xw$, $J=e^Te/(2N)$. Since $de=-X\,dw$, $dJ=e^Tde/N=-(X^Te)^Tdw/N$, so $\nabla J=-X^Te/N=X^T(Xw-y)/N$. Setting it to zero gives $X^TXw^*=X^Ty$. Because $X^TX/N$ is positive semidefinite, this condition is sufficient for a global minimum, even without full column rank.",
    "L02-S14-projection": r"$X^Te^*=0$ means every column of $X$ is orthogonal to $e^*$. With $\hat y=Xw^*\in\operatorname{col}(X)$, $y=\hat y+e^*$ is an orthogonal decomposition: $\hat y=Py$, $P^T=P$, $P^2=P$. The prediction is unique even if the weights are not. The left panel uses an orthonormal slice through these two vectors; the right checks every column.",
    "L02-S15-rank": r"Here $X=[a,\ a+\epsilon b]$, $a=(1,0,1)^T$, $b=(0,1,1)^T$. At $\epsilon=0$, the columns coincide: exact deficiency, rank 1 and nullity 1. At $\epsilon=10^{-5}$ they are still independent: near dependence, rank 2 and nullity 0. Near dependence creates sensitivity, not an exact family of equal predictions. Displayed rank uses a floating-point SVD threshold, not a symbolic proof for arbitrary matrices.",
    "L02-S16-family": r"All least-squares minimizers are $w^\dagger+v$, $v\in\operatorname{null}(X)$. Thus $X(w^\dagger+v)=Xw^\dagger$ and the training objective is unchanged. With duplicate columns, only their sum is identifiable. If nullity is zero, there is no nonzero null direction. Equal training predictions need not imply equal predictions at a new row outside the observed row space.",
    "L02-S16-initialization": r"For full-gradient descent on half-MSE, each update lies in $\operatorname{row}(X)$, so the initial null component is preserved. With $0<\gamma<2/\lambda_{\max}(X^TX/N)$, $w_k\to w^\dagger+P_{\rm null}w_0$. Zero initialization selects the minimum-norm solution; an arbitrary nonzero initialization need not. The plotted 80-step iterate is finite, not the analytical limit; near dependence can make convergence very slow.",
    "L02-S16-svd": r"Write $X=U_r\Sigma_rV_r^T$ on its nonzero singular directions; $X^+=V_r\Sigma_r^{-1}U_r^T$ and $w^\dagger=X^+y$. Since $w^\dagger\perp\operatorname{null}(X)$, $\|w^\dagger+v\|^2=\|w^\dagger\|^2+\|v\|^2$. The pseudoinverse selects the unique minimum Euclidean norm among minimizers, not the unique minimizer of the unregularized training objective.",
    "L02-S17-practice": r"The inverse expression requires full column rank. Least-squares minimizers still exist without that assumption. Use a least-squares routine based on QR or SVD; numerical stability and mathematical uniqueness are different questions.",
    "L02-S17-solvers": r"For full column rank, $w^*=(X^TX)^{-1}X^Ty$ is algebraically valid, but forming $X^TX$ squares the 2-norm condition number: $\kappa_2(X^TX)=\kappa_2(X)^2$. QR instead solves $Rw=Q^Ty$ without forming the Gram matrix. SVD exposes small/zero singular values and yields a minimum-norm solution at deficient rank. Use rank-revealing QR or SVD when rank is uncertain. A small residual or stationarity error alone does not certify accurate weights; differences here depend on floating-point arithmetic.",
    "L02-S18-synthesis": r"For a new design, inspect dimensions and rank first, then distinguish unique predictions on the training rows from identifiable parameters. Every least-squares solution satisfies $X^Te^*=0$. Full column rank gives unique weights; a nontrivial null space gives a family. QR/SVD address numerical computation; extra assumptions or measurements address identification.",
}

TRANSFER_CASES = {
    "duplicate": {"design": ((1., 1.), (2., 2.), (3., 3.)), "y": (1., 2., 2.), "prompt": "New design: two sensors report the same feature, X=[[1,1],[2,2],[3,3]]. Can training data identify their separate effects or predict at the new row (1,0)?", "answer": "Rank is 1, nullity is 1. Training predictions are unique but only the sum of the two coefficients is identifiable. The new row (1,0) distinguishes null-shifted solutions, so its prediction needs an additional assumption or measurement."},
    "wide": {"design": ((1., 0., 1.), (0., 1., 1.)), "y": (1., 2.), "prompt": "New design: two measurements, three coefficients, X=[[1,0,1],[0,1,1]]. Can zero training error establish a unique parameter vector?", "answer": "No. Full row rank makes every response interpolable, but rank 2 and nullity 1 leave infinitely many coefficients. SVD selects a minimum-norm representative; interpolation alone does not establish identification or generalization."},
    "independent": {"design": ((1., 0.), (0., 1.), (1., -1.)), "y": (1., 2., 0.), "prompt": "New design: X=[[1,0],[0,1],[1,-1]] with y=(1,2,0). Does having unique coefficients require zero residual?", "answer": "No. The two columns are independent, so the coefficients are unique, but y lies outside their column space. Least squares projects y onto that space and leaves a nonzero orthogonal residual; QR or SVD computes the solution."},
}


@dataclass(frozen=True)
class SceneData:
    design: np.ndarray
    y: np.ndarray
    minimum_weights: np.ndarray
    weights: np.ndarray
    prediction: np.ndarray
    residual: np.ndarray
    gradient: np.ndarray
    projector: np.ndarray
    rank: int
    rank_kind: str
    singular_values: np.ndarray
    condition: float
    null_basis: np.ndarray
    null_shift: np.ndarray
    normal_weights: object
    qr_weights: object
    initial_weights: np.ndarray
    gd_limit: np.ndarray
    gd_path: np.ndarray
    gamma: float


def scene_data(state):
    def invalid(detail):
        raise ValueError(f"{state.scene_id}: {detail}")
    shared, local = scene_presets(state.scene_id)
    if set(state.shared_state) != set(shared) or set(state.scene_state) != set(local):
        invalid("missing or undeclared control key")
    local = state.scene_state
    try:
        y = np.asarray(state.shared_state["s3.y"], dtype=float)
    except (ValueError, TypeError):
        invalid("s3.y must be numeric")
    if y.shape != (3,) or not np.isfinite(y).all() or np.max(np.abs(y)) > 100:
        invalid("s3.y must have three finite observations bounded by 100")
    for key, low, high in (("solution", 0, 1), ("null_step", -3, 3), ("collinearity", 0, 1)):
        value = local[key]
        if isinstance(value, bool) or not isinstance(value, (float, int)) or not np.isfinite(value) or not low <= value <= high:
            invalid(f"{key} must be finite in [{low},{high}]")
    if local["collinearity"] not in (0., 1e-5, 1.):
        invalid("collinearity must select an authored exact/near/full-rank design")
    if state.scene_id != "L02-S13" and local["solution"] != 1.:
        invalid("solution must be 1 outside the stationarity experiment")
    if local["initialization"] not in ("zero", "nonzero"):
        invalid("unknown initialization")
    if local["case"] not in TRANSFER_CASES:
        invalid("unknown transfer case")
    a, b = np.array([1., 0., 1.]), np.array([0., 1., 1.])
    X = np.column_stack((a, a + local["collinearity"] * b))
    if state.scene_id == "L02-S18":
        case = TRANSFER_CASES[local["case"]]
        X, y = np.array(case["design"]), np.array(case["y"])
    summary = least_squares_summary(X, y)
    projection = projection_summary(X, y)
    family = null_space_family(X, summary.weights)
    basis = family.basis.copy()
    for col in range(basis.shape[1]):
        if basis[np.argmax(np.abs(basis[:, col])), col] < 0:
            basis[:, col] *= -1
    # The orthogonal projector is independent of arbitrary SVD vector signs.
    u, _, _ = np.linalg.svd(X, full_matrices=False)
    projector = u[:, :summary.rank] @ u[:, :summary.rank].T
    vector = local["null_vector"]
    if vector is not None:
        try:
            vector = np.asarray(vector, dtype=float)
        except (TypeError, ValueError, OverflowError):
            invalid("null_vector must be numeric")
        if vector.shape != (X.shape[1],) or not np.isfinite(vector).all():
            invalid("null_vector must be a finite nonzero vector matching X columns")
        scale = np.max(np.abs(vector))
        if scale == 0:
            invalid("null_vector must be nonzero")
        if basis.shape[1] == 0:
            invalid("null_vector is unavailable when numerical nullity is zero")
        # Scaling first avoids squaring huge/tiny inputs when finding the norm.
        # Validate the direction we actually apply, not its arbitrary magnitude.
        scaled = vector / scale
        direction = scaled / np.linalg.norm(scaled)
        tolerance = 8 * np.finfo(float).eps * max(X.shape) * summary.singular_values[0]
        if np.linalg.norm(X @ direction) > tolerance:
            invalid("null_vector direction must satisfy X v = 0 within matrix-relative tolerance")
    else:
        direction = basis[:, 0] if basis.shape[1] else np.zeros(X.shape[1])
    shift = local["null_step"] * direction
    weights = local["solution"] * projection.weights + shift
    rank_kind = "exact deficiency" if summary.rank_deficient else ("near dependence" if summary.condition_number > 1e4 else "full rank")
    normal, qr = None, None
    if not summary.rank_deficient:
        q, r = np.linalg.qr(X, mode="reduced")
        qr = np.linalg.solve(r, q.T @ y)
        try:
            # Deliberately fragile baseline, only for comparing numerical practice.
            normal = np.linalg.inv(X.T @ X) @ (X.T @ y)
        except np.linalg.LinAlgError:
            normal = None
    initial = np.zeros(X.shape[1]) if local["initialization"] == "zero" else np.arange(1., X.shape[1] + 1.)
    gamma = len(y) / summary.singular_values[0]**2
    return SceneData(X, y, summary.weights, weights, X @ weights, y - X @ weights,
                     gradient_mse(X, y, weights), projector, summary.rank, rank_kind,
                     summary.singular_values, np.inf if summary.rank_deficient else summary.condition_number,
                     basis, shift, normal, qr, initial, summary.weights + basis @ basis.T @ initial,
                     gd_path(X, y, initial, learning_rate=gamma, steps=80), gamma)


def controls_for(state):
    sid = state.scene_id
    ref = (f"{sid}-" + {"L02-S13": "stationarity", "L02-S14": "projection", "L02-S15": "rank", "L02-S16": "family", "L02-S17": "practice", "L02-S18": "synthesis"}[sid],)
    rank = Control("collinearity", "column independence epsilon", (1., 1e-5, 0.), ref)
    if sid == "L02-S13":
        return (Control("solution", "fraction of solved weights", (0., .5, 1.), ref),)
    if sid == "L02-S16":
        controls = (Control("null_step", "null-space displacement t", (0., 1., 2., -1.), ref), rank)
        if state.layer_id == "initialization":
            controls += (Control("initialization", "GD initialization", ("zero", "nonzero"), ("L02-S16-initialization",)),)
        return controls
    if sid == "L02-S18":
        return (Control("case", "new design matrix", tuple(TRANSFER_CASES), ref),)
    return (rank,)


def validate_scene_contract(scene):
    from types import SimpleNamespace
    for layer in scene.layers:
        if not layer.math_refs or any(ref not in ANNOTATIONS for ref in layer.math_refs):
            raise ValueError(f"{scene.scene_id}: undeclared formula annotation")
        for control in controls_for(SimpleNamespace(scene_id=scene.scene_id, layer_id=layer.layer_id)):
            if control.key not in scene.state_ownership or not control.math_refs or any(ref not in scene.slide_claims for ref in control.math_refs):
                raise ValueError(f"{scene.scene_id}: undeclared control or math reference {control.key}")


def _observations(ax, data):
    indices = np.arange(1, len(data.y) + 1)
    ax.scatter(indices, data.y, color=COLORS["data"], label="observed y")
    ax.plot(indices, data.prediction, "o-", color=COLORS["mse"], label="Xw (training prediction)")
    ax.vlines(indices, data.prediction, data.y, color=COLORS["residual"], label="residual e")
    ax.set(xlabel="observation i", ylabel="response", xticks=indices)
    ax.legend(fontsize=9)


def scene_figure(sid, data, *, stage="explain", layer="explain"):
    fig = Figure(figsize=(14, 5), layout="constrained")
    axes = fig.subplots(1, 2)
    if stage == "predict":
        axes[0].imshow(data.design, cmap="Blues", aspect="auto")
        for (i, j), value in np.ndenumerate(data.design):
            axes[0].text(j, i, f"{value:g}", ha="center", va="center", color="black", bbox={"facecolor": "white", "alpha": .8, "edgecolor": "none"})
        axes[0].set(title="Inspect the design X before solving", xlabel="coefficient j", ylabel="observation i", xticks=range(data.design.shape[1]), yticks=range(len(data.y)))
        axes[1].bar(np.arange(1, len(data.y)+1), data.y, color=COLORS["data"])
        axes[1].set(xlabel="observation i", ylabel="observed y", title="Predict before revealing the solution")
    elif sid == "L02-S14":
        fitted = data.projector @ data.y
        length, residual = np.linalg.norm(fitted), np.linalg.norm(data.y-fitted)
        ax = axes[0]
        ax.axhline(0, color=COLORS["mse"], linewidth=2, label="slice through col(X)")
        for end, label, color in (((length, 0), "projection Py", COLORS["mse"]), ((length, residual), "observed y", COLORS["data"])):
            ax.annotate("", xy=end, xytext=(0, 0), arrowprops={"arrowstyle": "->", "color": color, "lw": 2})
            ax.annotate(label, end, xytext=(5, 8), textcoords="offset points", color=color)
        ax.plot([length, length], [0, residual], "o-", color=COLORS["residual"], label="orthogonal residual")
        radius = max(length, residual, 1.)
        ax.set(xlim=(-.2*radius, 1.55*radius), ylim=(-.2*radius, 1.35*radius), xlabel="unit direction along Py", ylabel="unit direction along e*", title="Orthogonal slice in observation space")
        ax.set_aspect("equal", adjustable="box")
        if length < 1e-12 or residual < 1e-12:
            ax.text(.02, .94, "Zero vector: its direction is arbitrary", transform=ax.transAxes, va="top")
        ax.legend(fontsize=9, loc="upper left")
        products = data.design.T @ (data.y-fitted)
        axes[1].bar(range(data.design.shape[1]), products, color=COLORS["residual"])
        axes[1].set(ylim=(-1, 1), xlabel="column j of X", ylabel="x_j^T e*", title=f"Every column is orthogonal: max |X^T e*|={np.max(np.abs(products)):.2g}")
    elif sid == "L02-S15" or (sid == "L02-S17" and layer != "qr-svd"):
        axes[0].plot(data.design[:, 0], "o-", color=COLORS["mse"], label="column 1")
        axes[0].plot(data.design[:, 1], "s--", color=COLORS["selected"], label="column 2")
        axes[0].set(xlabel="observation index", ylabel="feature value", title=data.rank_kind)
        axes[0].legend(fontsize=10)
        cutoff = np.finfo(float).eps * max(data.design.shape) * data.singular_values[0]
        axes[1].semilogy(range(1, len(data.singular_values)+1), np.maximum(data.singular_values, cutoff / 10), "o-", color=COLORS["residual"])
        axes[1].axhline(cutoff, linestyle=":", color=COLORS["selected"], label="numerical rank threshold")
        axes[1].set(xlabel="singular direction j", ylabel="singular value (log scale)", title=f"rank={data.rank}; nullity={data.null_basis.shape[1]}")
        axes[1].legend(fontsize=9)
    elif sid == "L02-S16":
        if layer == "initialization":
            for col in range(data.design.shape[1]):
                axes[0].plot(data.gd_path[:, col], label=f"w{col} iterate")
                axes[0].axhline(data.gd_limit[col], linestyle="--", alpha=.65, label=f"w{col} analytical limit")
            axes[0].set(xlabel="GD step k", ylabel="coefficient", title="Initial null component is preserved")
        else:
            t = np.linspace(-3, 3, 101)
            direction = data.null_basis[:, 0] if data.null_basis.shape[1] else np.zeros(data.design.shape[1])
            family = data.minimum_weights[:, None] + direction[:, None] * t
            if layer == "svd":
                axes[0].plot(t, np.sum(family**2, axis=0), color=COLORS["mse"], label="squared parameter norm")
                axes[0].scatter([0], [np.linalg.norm(data.minimum_weights)**2], color=COLORS["selected"], label="minimum-norm representative")
                axes[0].set(xlabel="null coordinate t", ylabel="||w_dagger + t v|| squared", title="Pythagoras in parameter space")
            else:
                axes[0].plot(*family[:2], color=COLORS["residual"], label="minimizer family")
                axes[0].scatter(*data.minimum_weights[:2], marker="*", s=150, color=COLORS["mse"], label="minimum norm")
                axes[0].scatter(*data.weights[:2], color=COLORS["selected"], label="current w")
                axes[0].set(xlabel="coefficient w0", ylabel="coefficient w1", title="Weights move; training predictions stay fixed")
                axes[0].set_aspect("equal", adjustable="datalim")
        axes[0].legend(fontsize=9)
        if data.null_basis.shape[1] == 0:
            axes[0].set_title("Nullity 0: no nonzero null direction")
        _observations(axes[1], data)
        axes[1].set_title(f"Half-MSE J={objective(data.design, data.y, data.weights):.5g}")
    elif sid == "L02-S17":
        names, weights = ["SVD/lstsq"], [data.minimum_weights]
        for name, value in (("QR", data.qr_weights), ("inverse Gram", data.normal_weights)):
            if value is not None:
                names.append(name)
                weights.append(value)
        axes[0].bar(names, [np.linalg.norm(w-data.minimum_weights) for w in weights], color=COLORS["selected"])
        axes[0].set(ylabel="||w_method - w_SVD||", title="Coefficient disagreement (not exact error)")
        axes[1].bar(names, [np.linalg.norm(data.design.T @ (data.y-data.design @ w)) for w in weights], color=COLORS["residual"])
        axes[1].set(ylabel="||X^T (y-Xw)||", title="Stationarity does not certify accurate weights")
        if data.normal_weights is None:
            axes[0].text(.03, .92, "Inverse unavailable at deficient rank", transform=axes[0].transAxes)
    else:
        _observations(axes[0], data)
        axes[0].set_title(f"rank={data.rank}; {data.rank_kind}")
        axes[1].bar(range(data.design.shape[1]), data.design.T @ data.residual, color=COLORS["residual"])
        axes[1].set(xlabel="column j of X", ylabel="x_j^T e = -N gradient_j", title="Normal equations: X^T e = 0 at the solution")
        axes[1].set_ylim(-max(1., np.max(np.abs(data.design.T @ data.y))), max(1., np.max(np.abs(data.design.T @ data.y))))
    for ax in axes:
        ax.grid(alpha=.15)
        ax.tick_params(labelsize=10)
    return fig


def render_scene(state):
    import marimo as mo
    from manifest import MANIFEST
    scene = next(s for s in MANIFEST.scenes if s.scene_id == state.scene_id)
    layer = next(l for l in scene.layers if l.layer_id == state.layer_id)
    data = scene_data(state)
    body = [mo.Html(f'<article data-scene="{escape(state.scene_id)}" data-visual-stage="{escape(layer.stage)}" data-render-sequence="{state.sequence}"></article>')]
    case = TRANSFER_CASES[state.scene_state["case"]] if state.scene_id == "L02-S18" else None
    if case:
        body.append(mo.md(case["prompt"]))
    body.append(mo.Html(figure_svg(scene_figure(state.scene_id, data, stage=layer.stage, layer=state.layer_id))))
    events, refs = [], []
    if layer.stage != "predict":
        if layer.stage in ("explain", "transfer"):
            body.append(mo.md(f"Design X = `{data.design.tolist()}`; response y = `{data.y.tolist()}`. Each row is an observation; no intercept is added automatically."))
            if state.scene_id != "L02-S18":
                body.append(mo.md("The columns are a and a + epsilon b, with a=(1,0,1) and b=(0,1,1). The epsilon control changes their independence."))
        for control in controls_for(state):
            value = state.scene_state[control.key]
            index = control.values.index(value) if value in control.values else -1
            following = control.values[(index + 1) % len(control.values)]
            body.append(mo.md(f"**{control.label}:** {value} → {following} on Apply `{control.key}`."))
            if layer.stage in ("explain", "transfer"):
                refs.extend(control.math_refs)
            events.append(StateEvent("write", scene_id=state.scene_id, key=control.key, value=following, label=control.label))
        body.append(mo.md(f"Design shape {data.design.shape}; rank={data.rank}; nullity={data.null_basis.shape[1]}; **{data.rank_kind}**. Half-MSE J={objective(data.design, data.y, data.weights):.6g}; ||X^T e||={np.linalg.norm(data.design.T @ data.residual):.6g}."))
        if state.scene_id == "L02-S16":
            body.append(mo.md(f"Null step t={state.scene_state['null_step']:g}; ||X v||={np.linalg.norm(data.design @ data.null_shift):.3g}; ||w||={np.linalg.norm(data.weights):.6g}; minimum norm={np.linalg.norm(data.minimum_weights):.6g}."))
        if layer.stage in ("explain", "transfer"):
            if state.scene_id == "L02-S13":
                body.append(mo.md(f"Current w = `{np.round(data.weights, 6).tolist()}`; X^T X w = `{np.round(data.design.T @ data.design @ data.weights, 6).tolist()}`; X^T y = `{np.round(data.design.T @ data.y, 6).tolist()}`. Their difference is N times the gradient. Apply solution until its fraction is 1 to see stationarity."))
            if state.scene_id == "L02-S16" and not data.null_basis.shape[1]:
                body.append(mo.md("Nullity 0: no nonzero null direction. Changing t cannot move the unique solution."))
            if state.layer_id == "initialization":
                body.append(mo.md(f"GD initialization: {state.scene_state['initialization']}; gamma={data.gamma:.6g}; ||P_null w0||={np.linalg.norm(data.null_basis @ data.null_basis.T @ data.initial_weights):.6g}; distance of step 80 to analytical limit={np.linalg.norm(data.gd_path[-1]-data.gd_limit):.6g}."))
    if layer.stage in ("explain", "transfer"):
        refs.extend(layer.math_refs)
        body.append(mo.md("**Return to the opening question:** " + scene.predict_prompt))
    body.extend(mo.md(ANNOTATIONS[ref]) for ref in dict.fromkeys(refs))
    if case and state.answer_visible:
        body.append(mo.callout(mo.md(case["answer"]), kind="info"))
    return SceneResult(mo.vstack(body), tuple(events))


def fallback_svg(scene):
    from course_player import LectureManifest, initial_player_state
    state = initial_player_state(LectureManifest((scene,)))
    if scene.scene_id == "L02-S13":
        state = replace(state, scene_state={**state.scene_state, "solution": 1.})
    if scene.scene_id == "L02-S16":
        state = replace(state, scene_state={**state.scene_state, "null_step": 2.})
    conclusions = {
        "L02-S13": "dJ = -e^T X dw / N, so gradient J = -X^T e / N. At a minimum X^T e = 0, equivalently X^T X w = X^T y. Positive semidefinite curvature makes stationarity sufficient, even if rank is deficient.",
        "L02-S14": "The residual is orthogonal to EVERY column: X^T e* = 0. The unique training prediction is the orthogonal projection Py, even if weights are nonunique. The plot is an orthonormal slice through Py and e*.",
        "L02-S15": "At epsilon=0 the columns coincide: exact deficiency, rank 1, nullity 1. At epsilon=1e-5 the columns remain independent: rank 2, nullity 0. Near dependence means sensitivity, not exact nonuniqueness.",
        "L02-S16": "Moving w_dagger by t v with Xv=0 changes the weights but leaves Xw and half-MSE fixed. Duplicate features identify only the coefficient sum. Full column rank has nullity 0, so no nonzero null direction exists.",
        "L02-S17": "The inverse formula requires full column rank; minimizers still exist at deficient rank. Favor a least-squares routine based on QR or SVD. Mathematical uniqueness and numerical stability are different questions.",
        "L02-S18": TRANSFER_CASES["duplicate"]["answer"],
    }
    figure = scene_figure(scene.scene_id, scene_data(state))
    figure.set_size_inches(14, 7.5)
    figure.set_layout_engine(None)
    figure.subplots_adjust(top=.73, bottom=.32, left=.085, right=.96, wspace=.38)
    figure.text(.035, .97, scene.title, fontsize=19, va="top")
    figure.text(.035, .91, fill(scene.predict_prompt, 115), fontsize=13, va="top")
    if scene.scene_id == "L02-S18":
        figure.subplots_adjust(top=.65)
        figure.text(.035, .83, fill(TRANSFER_CASES["duplicate"]["prompt"], 130), fontsize=11, va="top")
    figure.text(.035, .19, fill("Conclusion: " + conclusions[scene.scene_id], 130), fontsize=12, va="top")
    return figure_svg(figure)
