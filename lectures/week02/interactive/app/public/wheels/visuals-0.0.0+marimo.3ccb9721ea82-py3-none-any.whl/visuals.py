"""Deterministic linked figures shared by the live player and static fallbacks."""
from io import StringIO
from textwrap import fill

import matplotlib
from matplotlib.figure import Figure
import numpy as np

from public.model import loss_rho_psi

COLORS = {"data": "#264653", "selected": "#c53339", "residual": "#168276", "mse": "#3664ad", "mae": "#b76617", "huber": "#7b4ca5"}
LABELS = {"mse": "Half-MSE", "mae": "MAE", "huber": "Huber"}
DISPLAY_ZERO_TOLERANCE = 1e-12


def display_loss_point(residual, *, kind, delta):
    """Presentation only: classify |r| <= 1e-12 as zero, including MAE psi(0).

    The fitted parameters, raw residuals, objective and optimizer are untouched.
    This absolute tolerance uses the response units of this authored dataset.
    """
    shown = 0. if abs(residual) <= DISPLAY_ZERO_TOLERANCE else residual
    rho, psi = loss_rho_psi(np.array([shown]), kind=kind, delta=delta)
    return float(shown), float(rho[0]), float(psi[0])


def _points(ax, data, *, residuals=True):
    ax.scatter(data.x, data.y, color=COLORS["data"], s=45, label="observed y", zorder=4)
    ax.scatter(data.x[data.selected], data.y[data.selected], color=COLORS["selected"], marker="*", s=170, label=f"selected i={data.selected + 1}", zorder=5)
    if not data.fits:
        ax.plot(data.x, data.prediction, color=COLORS["mse"], label="prediction", linewidth=2.5)
        if residuals:
            ax.vlines(data.x, data.prediction, data.y, color=COLORS["residual"], linewidth=2)
            i = data.selected
            ax.vlines(data.x[i], data.prediction[i], data.y[i], color=COLORS["selected"], linewidth=3)
        ax.set_title(f"Rule: yhat = {data.weights[0]:.2f} + {data.weights[1]:.2f} x")
    else:
        for kind, fit in data.fits.items():
            ax.plot(data.x, data.design @ fit.weights, color=COLORS[kind], label=LABELS[kind], linewidth=2)
        ax.set_title(f"Same data; response shift = {data.outlier:+g}")
    ax.set(xlabel="input x", ylabel="response y")
    ax.legend(fontsize=10, loc="upper left")


def scene_figure(scene_id, data, *, stage="explain"):
    """No global pyplot registry; every call constructs one self-contained figure."""
    detailed = stage != "predict"
    if data.fits:
        panels = {"predict": 1, "manipulate": 1, "explain": 3, "transfer": 4}.get(stage, 3)
    else:
        panels = 2 if detailed else 1
    fig = Figure(figsize=(14, 6 if panels == 4 else 4.5), layout="constrained")
    rows, columns = ((2, 2) if panels == 4 else (1, panels))
    axes = np.atleast_1d(fig.subplots(rows, columns)).ravel()
    _points(axes[0], data, residuals=detailed and scene_id not in ("L02-S01", "L02-S02"))
    if panels == 1:
        return fig
    if data.fits:
        radius = max(3., data.delta * 1.3, max(abs(fit.point_residual) for fit in data.fits.values()) * 1.15)
        residual_grid = np.linspace(-radius, radius, 501)
        for kind, fit in data.fits.items():
            rho, psi = loss_rho_psi(residual_grid, kind=kind, delta=data.delta)
            axes[1].plot(residual_grid, rho, color=COLORS[kind], label=LABELS[kind], linewidth=2)
            if kind == "mae":
                axes[2].plot([-radius, 0, np.nan, 0, radius], [-1, -1, np.nan, 1, 1], color=COLORS[kind], label=LABELS[kind], linewidth=2)
                axes[2].scatter([0, 0], [-1, 1], facecolors="white", edgecolors=COLORS[kind], zorder=3)
                axes[2].scatter([0], [0], color=COLORS[kind], s=20, zorder=3)
            else:
                axes[2].plot(residual_grid, psi, color=COLORS[kind], label=LABELS[kind], linewidth=2)
            shown_r, shown_rho, shown_psi = display_loss_point(fit.point_residual, kind=kind, delta=data.delta)
            axes[1].scatter([shown_r], [shown_rho], color=COLORS[kind], edgecolors=COLORS["selected"], s=85, linewidths=2, zorder=4)
            axes[2].scatter([shown_r], [shown_psi], color=COLORS[kind], edgecolors=COLORS["selected"], s=85, linewidths=2, zorder=4, gid=f"selected-psi-{kind}")
        axes[1].set(xlabel="residual r", ylabel="rho(r)", title="Loss curve; outlined dots = selected point")
        axes[2].set(xlabel="residual r", ylabel="psi(r)", title=f"Residual influence; Huber delta = {data.delta:g}")
        axes[2].text(.99, .03, "Display only: |r| <= 1e-12 treated as zero", transform=axes[2].transAxes, ha="right", fontsize=9)
        for ax in axes[1:3]:
            for boundary in (-data.delta, data.delta):
                ax.axvline(boundary, color=COLORS["huber"], linestyle=":", alpha=.5)
            ax.legend(fontsize=10)
        if panels == 4:
            kinds = tuple(data.fits)
            values = [display_loss_point(data.fits[kind].point_residual, kind=kind, delta=data.delta)[1] / len(data.y) for kind in kinds]
            axes[3].bar([LABELS[kind] for kind in kinds], values, color=[COLORS[kind] for kind in kinds])
            axes[3].set(ylabel="rho(r_i) / N", title=f"Point {data.selected + 1} contribution at EACH fitted line")
            axes[3].set_ylim(0, max(values) * 1.25 if max(values) > 0 else 1)
            for i, value in enumerate(values):
                axes[3].annotate(f"{value:.3g}", (i, value), xytext=(0, 4), textcoords="offset points", ha="center")
    elif scene_id == "L02-S01":
        axes[1].axis("off")
        axes[1].text(.05, .65, "One shared rule\nyhat(x) = w0 + w1 x", fontsize=22)
        axes[1].text(.05, .30, f"Unseen x = 0.7\nyhat = {data.weights[0] + .7 * data.weights[1]:.2f}", fontsize=20)
    elif scene_id == "L02-S02":
        axes[1].plot(data.x, -np.ones(8), "o-", color=COLORS["mse"], label="delta w0 = +1: delta r = -1")
        axes[1].plot(data.x, -.5 * data.x, "s-", color=COLORS["residual"], label="delta w1 = +0.5: delta r = -0.5x")
        axes[1].set(xlabel="input x", ylabel="change in residual", title="Parameter changes couple all eight residuals")
        axes[1].legend(fontsize=10)
    else:
        objective = scene_id == "L02-S04"
        values = data.contributions if objective else data.residual
        axes[1].bar(np.arange(1, 9), values, color=[COLORS["selected"] if i == data.selected else COLORS["residual"] for i in range(8)])
        axes[1].set(xlabel="observation i", ylabel="r_i squared / (2N)" if objective else "r_i = y_i - yhat_i", title=f"Half-MSE J = sum of bars = {data.objective:.3f}" if objective else "Residual vector: eight signed coordinates")
        axes[1].set_xticks(np.arange(1, 9))
        if not objective:
            axes[1].text(.02, .96, f"||r|| = {np.linalg.norm(data.residual):.3f}", transform=axes[1].transAxes, va="top", fontsize=13)
    for ax in axes:
        if ax.axison:
            ax.grid(alpha=.16)
            ax.tick_params(labelsize=11)
    return fig


def figure_svg(figure):
    with matplotlib.rc_context({"svg.fonttype": "none", "svg.hashsalt": "lecture02-session1"}):
        stream = StringIO()
        figure.savefig(stream, format="svg", metadata={"Date": None})
    return "\n".join(line.rstrip() for line in stream.getvalue().splitlines()) + "\n"


def fallback_svg(scene):
    """Generate the committed, readable question/visual/conclusion fallback."""
    from dataclasses import replace
    from course_player import LectureManifest, initial_player_state
    from session1 import scene_data
    state = initial_player_state(LectureManifest((scene,)))
    if scene.scene_id in ("L02-S05", "L02-S06"):
        state = replace(state, shared_state={**state.shared_state, "s1.outlier": 8.})
    data = scene_data(state)
    conclusions = {
        "L02-S01": "One parameter pair defines predictions for every input, including unseen x. At x=0.7, this rule predicts yhat=0.35; the prediction is not an observed label.",
        "L02-S02": "Increasing w0 by 1 moves every prediction up by 1 and every residual down by 1. Increasing w1 by 0.5 changes each residual by -0.5x_i, with opposite effects on opposite sides of x=0.",
        "L02-S03": "Each signed vertical gap is r_i=y_i-yhat_i. Stacking gives r=y-Xw, an eight-dimensional vector. Opposite signs can cancel in a sum, but cannot erase its nonzero coordinates or norm.",
        "L02-S04": "Each bar is r_i squared / 16. Their sum is J=||r|| squared /(2N), N=8. This scalar keeps error magnitude without signed cancellation; doubling every residual quadruples J.",
        "L02-S05": "The +8 response contamination pulls half-MSE most: psi(r)=r is unbounded. MAE and Huber have bounded residual influence. Outlined dots track the SAME observation at each loss's fitted line; raw losses have different scales.",
        "L02-S06": "For occasional response corruption, Huber preserves quadratic behavior near zero and limits large residual influence. Set delta using ordinary noise scale; check feature leverage. Gaussian noise supports squared loss; Laplace noise supports absolute loss.",
    }
    figure = scene_figure(scene.scene_id, data, stage="transfer")
    figure.set_size_inches(14, 8 if data.fits else 5)
    figure.set_layout_engine(None)
    figure.subplots_adjust(top=.79, bottom=.23, left=.07, right=.97, wspace=.28, hspace=.55)
    figure.text(.035, .965, scene.title, fontsize=19, va="top")
    figure.text(.035, .905, fill(scene.predict_prompt, 105), fontsize=15, va="top")
    figure.text(.035, .16, fill("Conclusion: " + conclusions[scene.scene_id], 113), fontsize=14, va="top")
    return figure_svg(figure)
