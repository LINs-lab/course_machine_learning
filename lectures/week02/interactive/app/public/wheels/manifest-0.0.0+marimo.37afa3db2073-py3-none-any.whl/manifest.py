"""Authored Lecture 02 scenes implemented so far: Sessions 1–3.

Stable claim IDs are the handoff for later slide parity work. No later-session
stubs are registered: adding sessions extends MANIFEST and RENDERERS explicitly.
"""
from course_player import Layer, LectureManifest, Scene, Tier
from session1 import LOCAL_PRESET, SHARED_PRESET, render_scene, validate_scene_contract
import session2
import session3

_PODIUM = {1, 3, 5, 6, 8, 9, 11, 12, 14, 15, 16, 18}
_PAIR = {2, 7, 10, 13, 17}
_CUES = {
    1: ("Choose x=0.7 and read the line's prediction.", "The line defines values between measured points.", "A prediction comes from the rule; it is not a new observation."),
    2: ("Change the slope once and compare the two end residuals.", "The two ends move in opposite directions.", "A slope change affects residual i in proportion to -x_i."),
    3: ("Select one point and connect its vertical gap to one vector entry.", "The plotted gap and highlighted residual are the same quantity.", "The residual vector stores every signed prediction error."),
    4: ("Predict which residual dominates, then reveal its squared contribution.", "Squaring removes signs and magnifies large errors.", "Half-MSE adds squared residuals and divides by 2N."),
    5: ("Move only the outlier, then compare the three fitted lines.", "MSE rotates most; MAE changes least; Huber lies between.", "The loss derivative controls how strongly a large residual pulls the fit."),
    6: ("Choose a loss for the selected noise story before revealing the answer.", "Match tail behavior to the loss, not to habit.", "Loss choice encodes expected errors and their influence."),
    7: ("Move a short distance in one parameter direction.", "The tangent is accurate only for a small move.", "The gradient is the first-order change in the objective."),
    8: ("Apply one gradient step and trace the change across all three panels.", "Parameter, prediction, and loss views update together.", "One update w-gamma g determines the new line and loss."),
    9: ("Isolate the steep eigen-direction and raise gamma across the boundary.", "That coordinate flips and grows outside the stable interval.", "Stability requires 0 < gamma < 2/lambda_max."),
    10: ("Rescale one feature and compare the path.", "The valley stretches and gradient descent zig-zags.", "Conditioning measures unequal curvature; feature scale can change it."),
    11: ("Change batch size and compare the cloud with its star center.", "The cloud contracts around the unchanged full-gradient mean.", "Uniform mini-batch gradients are unbiased; dispersion falls with batch size."),
    12: ("Diagnose the failure before choosing an intervention.", "Different symptoms point to stability, conditioning, or sampling noise.", "Choose the intervention from the mechanism, not appearance alone."),
    13: ("Move the solution fraction to one and watch both stationarity displays.", "The gradient and column-residual inner products reach zero together.", "Zero gradient is equivalent to the normal equations."),
    14: ("Build prediction plus residual and identify the right angle.", "The fitted vector lies in col(X); the residual is perpendicular.", "Least squares projects y onto the column space of X."),
    15: ("Switch from exact duplicate to near duplicate columns.", "Rank changes only in the exact case; sensitivity appears near it.", "Near dependence is instability; exact dependence creates nonuniqueness."),
    16: ("Move along one null direction and compare weights, predictions, and loss.", "Weights move while training predictions and loss do not.", "Adding a null-space vector changes parameters but leaves Xw unchanged."),
    17: ("Choose a solver for the design and justify it.", "Stable computation cannot create missing information.", "QR or SVD improves computation; rank determines identifiability."),
    18: ("State rank, uniqueness, and solver before reveal.", "Prediction uniqueness and parameter uniqueness differ.", "Separate existence, identifiability, and numerical stability."),
}


def _facilitation(number):
    mode = "podium" if number in _PODIUM else ("pair" if number in _PAIR else "whole-class")
    task, watch, say = _CUES[number]
    return dict(participation=mode, student_task=task, watch_for=watch, say_it=say)

_CONTENT = (
    ("Data points → model as a rule", 4,
     "Can one rule predict a value at an input we have not observed?",
     "If x=0.7 was never measured, what does the current rule predict?",
     "Evaluate w0 + 0.7 w1. The model is a rule defined between the observations; an interpolation is a prediction, not a newly observed label.",
     ("rule",)),
    ("Parameters → coordinated changes", 6,
     "Will changing the intercept move all predictions equally? What changes for slope?",
     "Increase the slope by 0.5. What happens to residuals at x=-2 and x=2?",
     "Their changes are +1 and -1 respectively, since delta r_i = -x_i delta w1. Changing the intercept would instead shift every residual equally.",
     ("intercept", "slope")),
    ("Prediction errors → residual vector", 7,
     "Which vertical gaps are positive, and how do eight gaps become one vector?",
     "Two residuals are +2 and -2. Do their errors disappear when we stack them?",
     "No. The signed sum is zero, but the vector (2,-2) is nonzero and has Euclidean norm sqrt(8). Stacking preserves each observation's error.",
     ("residual",)),
    ("Residual vector → scalar objective", 7,
     "How can we score a whole residual vector without positive and negative errors canceling?",
     "If every residual doubles with N fixed, how does half-MSE change?",
     "It increases by a factor of four: ||2r||^2/(2N) = 4J. The norm doubles; the squared norm and half-MSE quadruple.",
     ("objective",)),
    ("Loss and influence → fitted lines", 10,
     "Move the last response upward. Which fitted line moves most, and why?",
     "With delta=1, a residual rises from 2 to 8. How do half-MSE, MAE, and Huber influence change?",
     "Half-MSE influence rises from 2 to 8. MAE stays at +1, and Huber stays at +1 because both residuals exceed delta=1. A larger loss value does not necessarily mean a larger derivative.",
     ("loss", "influence", "huber", "boundary", "gradient")),
    ("New noise situation → loss choice", 6,
     "Which loss would you defend for occasional corrupted sensor responses?",
     "State your noise assumption, preferred loss, and one diagnostic that could change your choice.",
     "Use the selected case's explanation: Gaussian noise supports squared loss, Laplace noise supports absolute loss, and response contamination can motivate Huber. Check the assumed mechanism, error costs, and feature leverage; no loss is universally best.",
     ("choice",)),
)


def _scene(number, content):
    title, minutes, predict, transfer, answer, names = content
    scene_id = f"L02-S{number:02d}"
    claims = tuple(f"{scene_id}-{name}" for name in names)
    core_claims = tuple(ref for ref in claims if not ref.endswith(("-boundary", "-gradient")))
    layers = [
        Layer("predict", "predict", Tier.CORE, 1, "Predict before reveal", math_refs=core_claims, next_core="manipulate"),
        Layer("manipulate", "manipulate", Tier.CORE, minutes - 3, "Apply an authored control preset", math_refs=core_claims, next_core="explain"),
        Layer("explain", "explain", Tier.CORE, 1, "Connect figure to formula", math_refs=core_claims, central_explanation=True, next_core="transfer", next_deepening="influence-gradient" if number == 5 else None),
        Layer("transfer", "transfer", Tier.CORE, 1, "Discuss new case; A reveals answer", math_refs=core_claims, next_reserve="huber-boundary" if number == 5 else None),
    ]
    if number == 5:
        layers += [Layer("influence-gradient", "explain", Tier.DEEPENING, 2, "Connect residual influence to parameter gradient", math_refs=("L02-S05-gradient",)), Layer("huber-boundary", "explain", Tier.RESERVE, 2, "Check both pieces at plus/minus delta", math_refs=("L02-S05-boundary",))]
    shared, local = tuple(SHARED_PRESET), tuple(LOCAL_PRESET)
    scene = Scene(scene_id, title, 1, minutes, (scene_id,), claims, predict, transfer, answer,
                  {**SHARED_PRESET, **LOCAL_PRESET}, shared, local,
                  {**dict.fromkeys(shared, "shared"), **dict.fromkeys(local, scene_id)}, shared + local,
                  tuple(layers), "session1.render_scene", dependencies=("public.model", "visuals"),
                  fallback=f"public/session1-S{number:02d}.svg",
                  notes="Same eight observations throughout Session 1. Sequential navigation carries declared s1 state; direct jumps restore presets. MSE is displayed with the canonical one-half normalization.",
                  **_facilitation(number))
    validate_scene_contract(scene)
    return scene


_SESSION2 = (
    ("Directional perturbation → local approximation", 6,
     "If we halve a small parameter perturbation, what happens to the tangent approximation error?",
     "For this quadratic, what happens to the approximation error when delta halves?",
     "The exact remainder is delta^T H delta / 2, so it becomes one quarter as large.", ("objective", "local")),
    ("One gradient step → three linked spaces", 7,
     "How does one gradient step change the fitted line, parameter point, and loss together?",
     "Can a gradient step increase the loss even though the negative gradient points downhill locally?",
     "Yes. The local approximation only guarantees decrease for a sufficiently small step. Excessive gamma can overshoot on the quadratic.", ("objective", "update")),
    ("Curvature → Hessian eigen-directions", 9,
     "Which direction bends the loss most, and what happens exactly at the stability boundary?",
     "If gamma equals 2/lambda_max, does the stiffest error component converge to zero?",
     "A nonzero component flips sign without decay. At gamma above the boundary it grows; a component initially zero stays zero. Reversing an eigenvector's sign changes neither curvature nor this conclusion.", ("hessian", "stability", "directions")),
    ("Conditioning → unequal contraction and zig-zags", 7,
     "Why can stable full-gradient steps zig-zag while progress along the valley stays slow?",
     "Would increasing batch size remove a zig-zag already present in full-batch GD?",
     "No. Unequal curvature is a conditioning issue. Check gamma against the Hessian spectrum, then consider normalization or preconditioning.", ("conditioning", "normalization")),
    ("Sample gradients → an exact gradient cloud", 8,
     "Where should the cloud of all size-B batch gradients be centered, and what happens at B=N?",
     "If the batch contains all eight observations, what sampling variance remains?",
     "Zero: there is only one batch and its gradient is the full gradient. For smaller uniform subsets without replacement, the finite-population correction matters; an exact universal 1/B claim is false.", ("cloud", "dispersion")),
    ("New optimization situation → method diagnosis", 6,
     "Which intervention addresses the cause: a smaller rate, feature normalization, or a larger batch?",
     "Identify the mechanism in the selected new case before choosing an intervention.",
     "Distinguish stability, unequal curvature, and sampling variability. More data in a batch cannot repair a full-gradient stability violation or remove unequal Hessian curvature.", ("diagnosis",)),
)


def _optimization_scene(number, content):
    title, minutes, predict, transfer, answer, names = content
    sid = f"L02-S{number:02d}"
    claims = tuple(f"{sid}-{name}" for name in names)
    core = tuple(ref for ref in claims if not ref.endswith(("-directions", "-normalization")))
    layers = [
        Layer("predict", "predict", Tier.CORE, 1, "Predict before reveal", math_refs=core, next_core="manipulate"),
        Layer("manipulate", "manipulate", Tier.CORE, minutes - 3, "Apply a mathematical control", math_refs=core, next_core="explain"),
        Layer("explain", "explain", Tier.CORE, 1, "Connect the linked views to half-MSE", math_refs=core, central_explanation=True, next_core="transfer", next_deepening="eigenbasis" if number == 9 else ("finite-population" if number == 11 else None)),
        Layer("transfer", "transfer", Tier.CORE, 1, "Diagnose a new case; A reveals answer", math_refs=core, next_reserve="normalization" if number == 10 else None),
    ]
    if number == 9:
        layers.append(Layer("eigenbasis", "explain", Tier.DEEPENING, 4, "Check sign invariance and isotropic curvature", math_refs=(f"{sid}-directions",)))
    if number == 10:
        layers.append(Layer("normalization", "explain", Tier.RESERVE, 3, "Rescale one feature and compare equivalent normalized coordinates", math_refs=(f"{sid}-normalization",)))
    if number == 11:
        layers.append(Layer("finite-population", "explain", Tier.DEEPENING, 3, "Derive the exact finite-population covariance", math_refs=(f"{sid}-dispersion",)))
    shared_preset, local_preset = session2.scene_presets(sid)
    shared, local = tuple(shared_preset), tuple(local_preset)
    preset = {**shared_preset, **local_preset}
    scene = Scene(sid, title, 2, minutes, (sid,), claims, predict, transfer, answer,
                  preset, shared, local,
                  {**dict.fromkeys(shared, "shared"), **dict.fromkeys(local, sid)}, shared + local,
                  tuple(layers), "session2.render_scene", dependencies=("public.model", "session1", "visuals"),
                  fallback=f"public/session2-S{number:02d}.svg",
                  notes="Half-MSE throughout. Same base observations as Session 1, with independent s2 state. Steps recompute the path from the authored line at the current rate; local scale preserves its predictions. S10 owns a scene-local rate for its fourfold feature units, so sequential and direct entry use the same stable preset. All batches are enumerated without replacement.",
                  **_facilitation(number))
    session2.validate_scene_contract(scene)
    return scene


_SESSION3 = (
    ("Zero gradient → normal equations", 8,
     "What equation must the residual satisfy when no parameter direction can lower half-MSE?",
     "If X has duplicate columns, is a zero gradient still sufficient for a global minimum?",
     "Yes. Half-MSE is convex with positive semidefinite Hessian X^T X/N. Stationarity is sufficient; duplicate columns remove uniqueness, not existence of a minimum.", ("stationarity",)),
    ("Normal equations → orthogonal projection", 9,
     "Why must the fitted residual be perpendicular to every column of the design?",
     "Can two least-squares minimizers produce different predictions on the training rows?",
     "No. The orthogonal projection of y onto col(X) is unique. Different minimizing weights can only differ by a vector in null(X).", ("projection",)),
    ("Feature dependence → rank deficiency", 7,
     "Do nearly identical features and exactly identical features have the same mathematical consequences?",
     "A second sensor reports x plus a tiny independent signal. Are its coefficients exactly nonunique?",
     "Not if the columns remain independent. The coefficients are unique but sensitive; exact duplicate columns create a nontrivial null space and nonunique coefficients.", ("rank",)),
    ("Null-space family → identifiable predictions", 10,
     "Can the coefficients move while every training prediction and the loss stay fixed?",
     "Two features coincide in training. Must two minimizing weights agree at a future row where the features differ?",
     "No. Null shifts preserve predictions on the training rows. A new row outside the observed row space may distinguish those weights, so prediction there needs extra assumptions or measurements.", ("family", "initialization", "svd")),
    ("Inverse formula → numerical solver choice", 1,
     "Why might a valid inverse formula still be a poor way to compute least squares?",
     "Does switching to a stable solver make duplicate-feature coefficients identifiable?",
     "No. A stable solver improves computation but does not create information. QR or SVD avoids a fragile explicit inverse; identification still depends on the design.", ("practice", "solvers")),
    ("New design matrix → synthesis and diagnosis", 7,
     "For an unfamiliar design, which quantities are unique and what computation would you trust?",
     "Inspect the selected new design: state rank, parameter uniqueness, prediction uniqueness, and a defensible solver.",
     "Separate existence, identification, and numerical stability. Projection is unique on training rows; a nonzero null space makes coefficients nonunique. Use QR or SVD, and justify predictions on new rows separately.", ("synthesis",)),
)


def _least_squares_scene(number, content):
    title, minutes, predict, transfer, answer, names = content
    sid = f"L02-S{number:02d}"
    claims = tuple(f"{sid}-{name}" for name in names)
    core = (claims[0],)
    # The shell requires a central Core explanation for every stable scene ID.
    # S17 is a one-minute gateway; all six minutes of solver detail are optional.
    durations = (.15, .2, .5, .15) if number == 17 else (1, minutes - 3, 1, 1)
    layers = [
        Layer("predict", "predict", Tier.CORE, durations[0], "Predict before reveal", math_refs=core, next_core="manipulate"),
        Layer("manipulate", "manipulate", Tier.CORE, durations[1], "Apply a design or parameter control", math_refs=core, next_core="explain"),
        Layer("explain", "explain", Tier.CORE, durations[2], "Return to the opening question with equations and geometry", math_refs=core, central_explanation=True, next_core="transfer", next_deepening="initialization" if number == 16 else ("qr-svd" if number == 17 else None)),
        Layer("transfer", "transfer", Tier.CORE, durations[3], "Diagnose a new design; A reveals answer", math_refs=core, next_reserve="svd" if number == 16 else None),
    ]
    if number == 16:
        layers += [Layer("initialization", "explain", Tier.DEEPENING, 3, "Compare zero and nonzero GD initialization", math_refs=("L02-S16-initialization",)), Layer("svd", "explain", Tier.RESERVE, 3, "Use SVD and Pythagoras to select minimum norm", math_refs=("L02-S16-svd",))]
    if number == 17:
        layers.append(Layer("qr-svd", "explain", Tier.DEEPENING, 6, "Compare inverse Gram, QR, and SVD computations", math_refs=("L02-S17-solvers",)))
    shared_preset, local_preset = session3.scene_presets(sid)
    shared, local = tuple(shared_preset), tuple(local_preset)
    scene = Scene(sid, title, 3, minutes, (sid,), claims, predict, transfer, answer,
                  {**shared_preset, **local_preset}, shared, local,
                  {**dict.fromkeys(shared, "shared"), **dict.fromkeys(local, sid)}, shared + local,
                  tuple(layers), "session3.render_scene", dependencies=("public.model", "session1", "visuals"),
                  fallback=f"public/session3-S{number:02d}.svg",
                  notes="Three-observation design; half-MSE normalization. Collinearity is scene-local so exact/near/full-rank presets agree on sequential and direct entry. S18 supplies new designs and responses. S17 has a one-minute Core gateway required by the player contract; six-minute QR/SVD detail is Deepening and is excluded from Core timing. S16 initialization is Deepening; pseudoinverse/minimum-norm derivation is Reserve.",
                  **_facilitation(number))
    session3.validate_scene_contract(scene)
    return scene


MANIFEST = LectureManifest(tuple(_scene(number, content) for number, content in enumerate(_CONTENT, 1)) + tuple(_optimization_scene(number, content) for number, content in enumerate(_SESSION2, 7)) + tuple(_least_squares_scene(number, content) for number, content in enumerate(_SESSION3, 13)), lecture_id="lecture02")
RENDERERS = {"session1.render_scene": render_scene, "session2.render_scene": session2.render_scene, "session3.render_scene": session3.render_scene}
