"""Pure, immutable state transitions for the reusable course player."""

from __future__ import annotations

from dataclasses import replace
from typing import Any, Callable, Mapping
from urllib.parse import parse_qs, urlencode

from .contracts import LectureManifest, PlayerState, Scene, SceneError, SceneResult, SceneSnapshot, StateEvent, Tier


def _scene(manifest: LectureManifest, scene_id: str) -> Scene:
    for scene in manifest.scenes:
        if scene.scene_id == scene_id:
            return scene
    raise ValueError(f"unknown scene {scene_id}")


def _layer(scene: Scene, layer_id: str):
    for layer in scene.layers:
        if layer.layer_id == layer_id:
            return layer
    raise ValueError(f"{scene.scene_id}: unknown layer {layer_id}")


def _first_core(scene: Scene):
    return next(layer for layer in scene.layers if layer.tier is Tier.CORE)


def _preset(scene: Scene) -> tuple[dict[str, Any], dict[str, Any]]:
    initial = scene.initial_state
    return (
        {key: initial[key] for key in scene.shared_state_keys if key in initial},
        {key: initial[key] for key in scene.scene_state_keys if key in initial},
    )


def initial_player_state(
    manifest: LectureManifest,
    *,
    scene_id: str | None = None,
    layer_id: str | None = None,
    depth: int = 0,
    answer_visible: bool = False,
) -> PlayerState:
    """Start a scene from authored presets, never a prior mutable session."""
    if not manifest.scenes:
        raise ValueError("manifest has no scenes")
    scene = _scene(manifest, scene_id or manifest.scenes[0].scene_id)
    layer = _layer(scene, layer_id) if layer_id else _first_core(scene)
    if depth not in (0, 1) or (depth == 0 and layer.tier is not Tier.CORE) or (depth == 1 and layer.tier is Tier.CORE):
        raise ValueError("invalid navigation depth")
    shared, local = _preset(scene)
    return PlayerState(scene.scene_id, layer.layer_id, depth, answer_visible, shared, local)


def _snapshot(state: PlayerState) -> SceneSnapshot:
    return SceneSnapshot(
        state.layer_id, state.depth, state.answer_visible,
        dict(state.shared_state), dict(state.scene_state),
    )


def _enter_scene(
    manifest: LectureManifest,
    state: PlayerState,
    target: Scene,
    *,
    layer_id: str | None = None,
    restore_snapshot: bool = False,
    carry_shared: bool = False,
) -> PlayerState:
    snapshots = dict(state.snapshots)
    snapshots[state.scene_id] = _snapshot(state)
    if restore_snapshot and target.scene_id in snapshots:
        saved = snapshots[target.scene_id]
        return PlayerState(
            target.scene_id, saved.layer_id, saved.depth, saved.answer_visible,
            dict(saved.shared_state), dict(saved.scene_state), snapshots, state.sequence,
        )
    layer = _layer(target, layer_id) if layer_id else _first_core(target)
    shared, local = _preset(target)
    if carry_shared:
        # Sequential traversal carries only target-declared shared values.
        shared.update({key: state.shared_state[key] for key in target.shared_state_keys if key in state.shared_state})
    return PlayerState(target.scene_id, layer.layer_id, 0, False, shared, local, snapshots, state.sequence)


def _with_sequence(state: PlayerState, event: StateEvent, **changes: Any) -> PlayerState:
    changes.setdefault("warning", None)
    return replace(state, sequence=event.sequence, **changes)


def reduce(manifest: LectureManifest, state: PlayerState, event: StateEvent) -> PlayerState:
    """Apply exactly one event; stale events are harmless no-ops."""
    if event.sequence <= state.sequence:
        return state
    scene = _scene(manifest, state.scene_id)
    current = _layer(scene, state.layer_id)
    if event.kind == "write":
        if event.scene_id not in (None, scene.scene_id):
            raise ValueError(f"{scene.scene_id}: does not own state for {event.scene_id}")
        if not event.key or event.key not in scene.state_ownership:
            raise ValueError(f"{scene.scene_id}: undeclared state key {event.key}")
        owner = scene.state_ownership[event.key]
        if owner == "shared":
            values = dict(state.shared_state)
            values[event.key] = event.value
            return _with_sequence(state, event, shared_state=values)
        if owner != scene.scene_id or event.scene_id not in (None, scene.scene_id):
            raise ValueError(f"{scene.scene_id}: does not own local key {event.key}")
        values = dict(state.scene_state)
        values[event.key] = event.value
        return _with_sequence(state, event, scene_state=values)
    if event.kind == "reset":
        shared, local = _preset(scene)
        new_shared = dict(state.shared_state)
        new_local = dict(state.scene_state)
        for key in scene.reset_scope:
            if scene.state_ownership.get(key) == "shared" and key in shared:
                new_shared[key] = shared[key]
            elif scene.state_ownership.get(key) == scene.scene_id and key in local:
                new_local[key] = local[key]
        return _with_sequence(state, event, shared_state=new_shared, scene_state=new_local)
    if event.kind == "toggle_answer":
        return _with_sequence(state, event, answer_visible=not state.answer_visible)
    if event.kind == "reveal":
        if current.tier is not Tier.CORE or current.next_core is None:
            return _with_sequence(state, event)
        return _with_sequence(state, event, layer_id=current.next_core, depth=0, answer_visible=False)
    if event.kind == "deepen":
        target_id = current.next_deepening or current.next_reserve or next((branch for branch in current.branches if _layer(scene, branch).tier is not Tier.CORE), None)
        if target_id is None:
            return _with_sequence(state, event)
        return _with_sequence(state, event, layer_id=target_id, depth=1)
    if event.kind == "up":
        if current.tier is Tier.CORE:
            return _with_sequence(state, event)
        parent = next((node for node in scene.layers if current.layer_id in (node.next_deepening, node.next_reserve, *node.branches)), None)
        if parent is None:
            return _with_sequence(state, event)
        return _with_sequence(state, event, layer_id=parent.layer_id, depth=0)
    if event.kind == "jump":
        try:
            target = _scene(manifest, event.scene_id or "")
        except ValueError:
            return _with_sequence(state, event, warning=f"unknown scene {event.scene_id}; stayed on {scene.scene_id}")
        return replace(_enter_scene(manifest, state, target), sequence=event.sequence)
    if event.kind == "refresh":
        return replace(
            initial_player_state(
                manifest, scene_id=state.scene_id, layer_id=state.layer_id,
                depth=state.depth, answer_visible=state.answer_visible,
            ),
            sequence=event.sequence,
        )
    if event.kind == "next":
        index = manifest.scene_ids.index(scene.scene_id)
        if index + 1 >= len(manifest.scenes):
            return _with_sequence(state, event)
        return replace(_enter_scene(manifest, state, manifest.scenes[index + 1], restore_snapshot=True, carry_shared=True), sequence=event.sequence)
    if event.kind == "previous":
        index = manifest.scene_ids.index(scene.scene_id)
        if index == 0:
            return _with_sequence(state, event)
        return replace(_enter_scene(manifest, state, manifest.scenes[index - 1], restore_snapshot=True, carry_shared=True), sequence=event.sequence)
    raise ValueError(f"unknown state event {event.kind}")


def serialize_url(state: PlayerState) -> str:
    """Serialize navigation only; mathematical controls remain private to memory."""
    return "?" + urlencode({"scene": state.scene_id, "layer": state.layer_id, "depth": state.depth, "answer": int(state.answer_visible)})


def restore_url(manifest: LectureManifest, url: str) -> PlayerState:
    """Restore URL navigation from authored presets, warning rather than failing."""
    query = parse_qs(url.split("?", 1)[1] if "?" in url else url, keep_blank_values=True)
    try:
        scene_id = query["scene"][0]
        layer_id = query["layer"][0]
        depth = int(query["depth"][0])
        answer = query["answer"][0]
        if not scene_id or not layer_id:
            raise ValueError("blank scene or layer")
        if answer not in {"0", "1"}:
            raise ValueError("invalid answer")
        return initial_player_state(manifest, scene_id=scene_id, layer_id=layer_id, depth=depth, answer_visible=answer == "1")
    except (KeyError, IndexError, TypeError, ValueError):
        state = initial_player_state(manifest)
        return replace(state, warning="Invalid player URL; restored the first scene preset.")


def validate_scene_event(scene: Scene, event: StateEvent) -> None:
    """Renderer proposals may write owned controls, never shell navigation."""
    if (not isinstance(event, StateEvent) or event.kind != "write"
            or event.scene_id not in (None, scene.scene_id)
            or event.key not in scene.state_ownership
            or scene.state_ownership[event.key] not in ("shared", scene.scene_id)):
        raise ValueError(f"{scene.scene_id}: rejected renderer proposal; expected an owned control write")


def dispatch_renderer(
    manifest: LectureManifest,
    state: PlayerState,
    *,
    renderers: Mapping[str, Callable[[PlayerState], SceneResult]] | None = None,
) -> SceneResult | SceneError:
    """Invoke only the selected renderer and contain all renderer failures."""
    scene = _scene(manifest, state.scene_id)
    renderer = renderers.get(scene.renderer) if isinstance(scene.renderer, str) and renderers else scene.renderer
    try:
        if not callable(renderer):
            raise TypeError(f"renderer is not callable: {scene.renderer}")
        result = renderer(state)
        if not isinstance(result, SceneResult):
            raise TypeError("renderer must return SceneResult")
        for event in result.events:
            validate_scene_event(scene, event)
        return result
    except Exception as exc:
        return SceneError(scene.scene_id, f"{type(exc).__name__}: {exc}", scene.fallback or "Use the scene's static fallback.")
