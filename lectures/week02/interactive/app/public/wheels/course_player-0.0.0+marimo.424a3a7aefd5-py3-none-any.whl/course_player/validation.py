"""Pre-render validation for lecture manifests."""

from collections.abc import Callable, Mapping

from .contracts import Layer, LectureManifest, Tier, ValidationReport

_STAGES = {"predict", "manipulate", "explain", "transfer"}
_PARTICIPATION = {"podium", "whole-class", "pair", "instructor"}


class ManifestError(ValueError):
    """A manifest cannot be safely rendered; message names the bad contract."""


def _error(scene_id: str, detail: str) -> ManifestError:
    return ManifestError(f"{scene_id}: {detail}")


def _distance_to_central(scene_id: str, layers: tuple[Layer, ...]) -> int:
    by_id = {layer.layer_id: layer for layer in layers}
    if len(by_id) != len(layers):
        raise _error(scene_id, "duplicate layer_id")
    for layer in layers:
        for target in (layer.next_core, layer.next_deepening, layer.next_reserve, *layer.branches):
            if target is not None and target not in by_id:
                raise _error(scene_id, f"unknown layer edge {target}")
        for prerequisite in layer.prerequisites:
            if prerequisite not in by_id:
                raise _error(scene_id, f"unknown prerequisite {prerequisite}")
            if by_id[prerequisite].tier is not Tier.CORE and layer.tier is Tier.CORE:
                raise _error(scene_id, f"Core layer {layer.layer_id} depends on optional layer {prerequisite}")
        if layer.stage.lower() not in _STAGES:
            raise _error(scene_id, f"invalid stage {layer.stage}")
        if not layer.action:
            raise _error(scene_id, f"layer {layer.layer_id} has missing action")
        if layer.next_core is not None and by_id[layer.next_core].tier is not Tier.CORE:
            raise _error(scene_id, f"next_core target {layer.next_core} must be Core")
    # Every declared edge is part of the action graph; optional branches must
    # not introduce a cycle that can trap the player.
    visiting: set[str] = set()
    visited: set[str] = set()
    def visit(layer_id: str) -> None:
        if layer_id in visiting:
            raise _error(scene_id, "cycle in action graph")
        if layer_id in visited:
            return
        visiting.add(layer_id)
        node = by_id[layer_id]
        for target in (node.next_core, node.next_deepening, node.next_reserve, *node.branches):
            if target is not None:
                visit(target)
        visiting.remove(layer_id)
        visited.add(layer_id)
    for layer in layers:
        visit(layer.layer_id)
    central = [layer for layer in layers if layer.central_explanation]
    if len(central) != 1 or central[0].tier is not Tier.CORE:
        raise _error(scene_id, "requires exactly one central Core explanation")
    prerequisites = {layer.layer_id: layer.prerequisites for layer in layers}
    visiting.clear()
    visited.clear()
    def visit_prerequisites(layer_id: str) -> None:
        if layer_id in visiting:
            raise _error(scene_id, "cycle in prerequisite graph")
        if layer_id in visited:
            return
        visiting.add(layer_id)
        for prerequisite in prerequisites[layer_id]:
            visit_prerequisites(prerequisite)
        visiting.remove(layer_id)
        visited.add(layer_id)
    for layer in layers:
        visit_prerequisites(layer.layer_id)
    start = next((layer for layer in layers if layer.tier is Tier.CORE), None)
    if start is None:
        raise _error(scene_id, "requires a Core layer")
    goal = central[0].layer_id
    # next_core is the authored Core route; optional branches are intentionally omitted.
    distance = 0
    current = start.layer_id
    visited: set[str] = set()
    while current != goal:
        if current in visited:
            raise _error(scene_id, "cycle in Core action graph")
        visited.add(current)
        node = by_id[current]
        if node.next_core is None:
            raise _error(scene_id, "central explanation is unreachable")
        current = node.next_core
        distance += 1
        if distance > 2:
            raise _error(scene_id, "central explanation is more than two actions")
    return distance


def validate_manifest(manifest: LectureManifest, *, renderers: Mapping[str, Callable] | None = None) -> ValidationReport:
    """Validate scene shape and Core action reachability before first render."""
    if not isinstance(manifest, LectureManifest):
        raise ManifestError("manifest: expected LectureManifest")
    ids_seen: set[str] = set()
    for scene in manifest.scenes:
        if scene.scene_id in ids_seen:
            raise _error(scene.scene_id, f"duplicate scene_id {scene.scene_id}")
        ids_seen.add(scene.scene_id)
    seen: set[str] = set()
    distances: dict[str, int] = {}
    for scene in manifest.scenes:
        if not scene.scene_id:
            raise ManifestError("scene: missing scene_id")
        if scene.scene_id in seen:
            raise _error(scene.scene_id, f"duplicate scene_id {scene.scene_id}")
        seen.add(scene.scene_id)
        if not scene.title or not scene.slide_refs:
            raise _error(scene.scene_id, "missing required title or slide_refs")
        if not scene.slide_claims:
            raise _error(scene.scene_id, "missing slide claim")
        if not scene.predict_prompt or not scene.transfer_prompt:
            raise _error(scene.scene_id, "missing Predict or Transfer prompt")
        if scene.participation not in _PARTICIPATION:
            raise _error(scene.scene_id, f"invalid participation {scene.participation}")
        cues = (scene.student_task, scene.watch_for, scene.say_it)
        if any(cues) and not all(isinstance(cue, str) and cue.strip() for cue in cues):
            raise _error(scene.scene_id, "facilitation cues must be a complete nonblank set")
        if any(ref not in scene.slide_claims for layer in scene.layers for ref in layer.math_refs):
            missing = next(ref for layer in scene.layers for ref in layer.math_refs if ref not in scene.slide_claims)
            raise _error(scene.scene_id, f"missing slide claim {missing}")
        if any(layer.tier is Tier.CORE for layer in scene.layers) and not scene.fallback:
            raise _error(scene.scene_id, "missing fallback")
        renderer = scene.renderer
        if isinstance(renderer, str):
            renderer = renderers.get(renderer) if renderers is not None else None
        if not callable(renderer):
            symbol = scene.renderer if isinstance(scene.renderer, str) else type(scene.renderer).__name__
            raise _error(scene.scene_id, f"renderer is not callable: {symbol}")
        stages = {layer.stage.lower() for layer in scene.layers}
        if stages != _STAGES:
            raise _error(scene.scene_id, "missing required Predict/Manipulate/Explain/Transfer stage")
        if not scene.transfer_answer:
            raise _error(scene.scene_id, "missing Transfer answer")
        distances[scene.scene_id] = _distance_to_central(scene.scene_id, scene.layers)
    return ValidationReport(scene_ids=manifest.scene_ids, action_distances=distances)
