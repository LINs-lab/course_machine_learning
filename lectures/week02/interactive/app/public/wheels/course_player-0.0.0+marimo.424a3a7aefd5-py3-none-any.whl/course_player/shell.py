"""Marimo presentation adapter. All transitions live in navigation.reduce.

Create a PlayerController once in a setup cell. Give it an on_change callback
that updates mo.state; call render_player in a cell reading that state getter.
Renderers return SceneResult bodies and optional explicit event buttons.
"""
from dataclasses import dataclass, replace
from html import escape
from urllib.parse import parse_qs, urlencode
from uuid import uuid4

from .contracts import SceneError, StateEvent
from .navigation import dispatch_renderer, initial_player_state, reduce, restore_url, serialize_url, validate_scene_event
from .validation import validate_manifest


# Keyboard navigation activates the same native button callback, including
# when a navigation button retains focus after a mouse click.
CONTROLS = (
    ("previous", "← Previous", "ArrowLeft", "ArrowLeft"),
    ("next", "Next →", "ArrowRight", "ArrowRight"),
    ("reveal", "Reveal · Space", " ", "Space"),
    ("deepen", "Explore further ↓", "ArrowDown", "ArrowDown"),
    ("up", "Main path ↑", "ArrowUp", "ArrowUp"),
    ("toggle_answer", "Answer · A", "a", "a"),
    ("reset", "Reset · R", "r", "r"),
)
KEY_ACTIONS = {key: action for action, _, key, _ in CONTROLS}


def teaching_stage_css():
    """Shared classroom layout; intentionally independent of lecture content."""
    return """<style>
:root { --stage-red:#a6192e; --stage-ink:#20242a; --stage-muted:#66707a;
  --stage-paper:#fbfaf7; --stage-line:#d9dde2; --stage-soft:#f1f3f5; }
body { background:var(--stage-paper); color:var(--stage-ink); }
.teaching-top { border-top:7px solid var(--stage-red); padding:12px 16px 9px;
  background:white; box-shadow:0 1px 0 var(--stage-line); }
.teaching-top h2 { margin:0; font-size:clamp(1.4rem,2.2vw,2.15rem); line-height:1.08; }
.teaching-meta { display:flex; align-items:center; gap:12px; margin-top:7px;
  color:var(--stage-muted); font-size:.9rem; }
.stage-pills { display:flex; gap:5px; margin-left:auto; }
.stage-pills span { border:1px solid var(--stage-line); border-radius:999px; padding:2px 8px; }
.stage-pills .active { color:white; background:var(--stage-red); border-color:var(--stage-red); }
.teaching-stage { display:grid; grid-template-columns:minmax(190px,1fr) minmax(430px,3.2fr) minmax(210px,1.15fr); gap:16px; align-items:start; }
div:has(> div > .teaching-task) { align-items:flex-start !important; gap:16px !important; }
.teaching-rail { background:white; border:1px solid var(--stage-line); border-radius:10px;
  padding:14px; box-shadow:0 5px 16px rgba(32,36,42,.05); }
.teaching-rail h3 { margin:0 0 8px; color:var(--stage-red); font-size:.78rem;
  text-transform:uppercase; letter-spacing:.09em; }
.teaching-rail p { margin:0 0 14px; line-height:1.38; }
.participation { display:inline-block; margin-bottom:14px; padding:4px 8px;
  border-radius:4px; background:var(--stage-ink); color:white; font-size:.72rem;
  font-weight:700; letter-spacing:.06em; text-transform:uppercase; }
.teaching-main { min-width:0; background:white; border:1px solid var(--stage-line);
  border-radius:10px; padding:12px 16px; }
.teaching-main-marker { display:none; }
.teaching-main svg { width:100%; max-height:58vh; }
.teaching-transport { padding:8px 16px 4px; }
.teaching-transport button { min-height:36px; }
.teaching-utility { opacity:.78; font-size:.9rem; }
@media (max-width: 900px) {
  .teaching-stage { grid-template-columns:1fr; }
  div:has(> div > .teaching-task) { flex-direction:column !important; }
  div:has(> div > .teaching-task) > div { width:100% !important; flex:1 1 auto !important; }
  .teaching-task { order:1; } .teaching-main { order:2; } .teaching-explain { order:3; }
  .stage-pills { width:100%; margin-left:0; flex-wrap:wrap; }
  .teaching-meta { flex-wrap:wrap; }
}
</style>"""


def facilitation_panel_html(scene, stage, side="all"):
    labels = {"podium": "Student at controls", "whole-class": "Whole-class check",
              "pair": "Pair discussion", "instructor": "Instructor demo"}
    task = (f'<section class="teaching-rail teaching-task" data-participation="{escape(scene.participation, quote=True)}">'
            f'<span class="participation">{escape(labels[scene.participation])}</span>'
            f'<h3>Question</h3><p>{escape(scene.predict_prompt)}</p>'
            f'<h3>Student task</h3><p>{escape(scene.student_task)}</p></section>')
    explain = (f'<section class="teaching-rail teaching-explain"><h3>Watch for</h3>'
               f'<p>{escape(scene.watch_for)}</p>'
               + (f'<h3>Say it</h3><p>{escape(scene.say_it)}</p>' if stage.lower() in ("explain", "transfer") else "")
               + "</section>")
    return task if side == "task" else (explain if side == "explain" else task + explain)


def scene_event_label(event):
    readable = event.label or (event.key.rsplit(".", 1)[-1].replace("_", " ") if event.key else event.kind.replace("_", " "))
    return f"Apply {readable}"

KEYBOARD_BRIDGE = """<script>
const doc = parent.document;
const keys = {ArrowLeft:'previous', ArrowRight:'next', ArrowDown:'deepen',
 ArrowUp:'up', ' ':'reveal', a:'toggle_answer', r:'reset'};
const actions = new Set(Object.values(keys));
const isSceneAction = action => action.startsWith('scene-event-');
const header = () => doc.querySelector('[data-player-transport]');
const identity = header().dataset.playerTransport;
if (parent.__coursePlayerBridge) parent.__coursePlayerBridge();
if (parent.__coursePlayerTransport?.identity !== identity) {
 parent.__coursePlayerTransport = {identity, pending:[], inflight:null, replaying:false};
}
const transport = parent.__coursePlayerTransport;
const findButton = root => {
 for (const node of root.querySelectorAll('*')) {
   if (node.tagName === 'BUTTON') return node;
   if (node.shadowRoot) { const found = findButton(node.shadowRoot); if (found) return found; }
 }
};
let frame = null;
const schedule = () => {
 if (frame === null) frame = parent.requestAnimationFrame(drain);
};
const drain = () => {
 frame = null;
 const current = header();
 if (!current || current.dataset.playerTransport !== identity) return;
 const ack = Number(current.dataset.playerActionAck);
 if (transport.inflight !== null) {
   if (ack < transport.inflight) return;
   transport.inflight = null;
 }
 if (!transport.pending.length) return;
 const action = transport.pending[0];
 const wrapper = [...doc.querySelectorAll('[data-player-action]')].find(node => node.dataset.playerAction === action);
 /* Navigation can remove a queued control's original scene/key.
    Discard that obsolete intent without blocking later actions. */
 if (!wrapper && isSceneAction(action)) {
   transport.pending.shift(); schedule(); return;
 }
 const button = wrapper && findButton(wrapper);
 if (!button || button.disabled) return;
 transport.pending.shift();
 transport.inflight = ack + 1;
 transport.replaying = true;
 try { button.click(); } finally { transport.replaying = false; }
};
const enqueue = (event, action) => {
 event.preventDefault(); event.stopImmediatePropagation();
 transport.pending.push(action); schedule();
};
const click = event => {
 if (transport.replaying) return;
 const wrapper = event.composedPath().find(node => node.dataset?.playerAction);
 if (wrapper && (actions.has(wrapper.dataset.playerAction) || isSceneAction(wrapper.dataset.playerAction))) enqueue(event, wrapper.dataset.playerAction);
};
const keydown = event => {
 if (event.altKey || event.ctrlKey || event.metaKey) return;
 if (event.composedPath().some(node => node instanceof parent.HTMLElement &&
   (['INPUT','TEXTAREA','SELECT'].includes(node.tagName) || node.isContentEditable ||
    node.getAttribute('role') === 'textbox' || node.getAttribute('role') === 'combobox'))) return;
 const action = keys[event.key.length === 1 ? event.key.toLowerCase() : event.key];
 if (action) enqueue(event, action);
};
const observer = new parent.MutationObserver(schedule);
observer.observe(doc.body, {subtree:true, childList:true, attributes:true});
doc.addEventListener('click', click, true);
doc.addEventListener('keydown', keydown, true);
const cleanup = () => {
 doc.removeEventListener('click', click, true);
 doc.removeEventListener('keydown', keydown, true);
 observer.disconnect();
 if (frame !== null) parent.cancelAnimationFrame(frame);
 if (parent.__coursePlayerBridge === cleanup) delete parent.__coursePlayerBridge;
};
parent.__coursePlayerBridge = cleanup;
addEventListener('unload', cleanup);
schedule();
</script>"""


@dataclass(frozen=True)
class PlayerView:
    body: object
    warning: str | None
    recovery: str | None
    actions: tuple[str, ...]
    events: tuple[StateEvent, ...] = ()


class PlayerController:
    """Session adapter with sequenced events and exactly one lazy render."""

    def __init__(self, manifest, *, renderers=None, url="", on_change=None):
        validate_manifest(manifest, renderers=renderers)
        self.manifest = manifest
        self.renderers = renderers
        self.state = restore_url(manifest, url) if url else initial_player_state(manifest)
        self.on_change = on_change
        self.query_params = None
        self.last_url = url
        self.widgets = {}
        self.last_view = None
        self.transport_id = uuid4().hex
        self.action_ack = 0

    def dispatch(self, event):
        # Unsequenced native clicks allocate from committed state. Explicit
        # renderer/DOM sequences retain the reducer's stale-event protection.
        event = event if event.sequence else replace(event, sequence=self.state.sequence + 1)
        updated = reduce(self.manifest, self.state, event)
        if updated is self.state:
            return self.state.sequence
        self.state = updated
        self.last_url = serialize_url(self.state)
        if self.query_params is not None:
            for key, values in parse_qs(self.last_url[1:]).items():
                if self.query_params.get(key) != values[0]:
                    self.query_params[key] = values[0]
        if self.on_change is not None:
            self.on_change(self.state.sequence)
        return self.state.sequence

    def action(self, kind, *, scene_id=None):
        return self.dispatch(StateEvent(kind, scene_id=scene_id))

    def submit_action(self, kind):
        # A separate acknowledgement prevents unrelated scene/control events
        # from releasing the next queued navigation action prematurely.
        self.action_ack += 1
        return self.action(kind)

    def submit_scene_event(self, event, *, intent_index=None):
        """Resolve a UI intent's authored slot against committed state.

        Rendered callbacks carry a stable list slot as well as scene/kind/key;
        renderers must retain the meaning and order of their action slots across
        rerenders. Values may change, including several intents for the same key.
        Without a slot this is an absolute StateEvent, not a dynamic UI intent.
        Explicit sequences always retain normal stale rejection.
        """
        self.action_ack += 1
        before = self.state
        try:
            # Preserve stale/obsolete callback ACKs, then guard the final boundary
            # separately from shell-owned action(), which may navigate.
            if event.sequence and event.sequence <= self.state.sequence:
                return self.state.sequence
            if event.scene_id not in (None, self.state.scene_id):
                return self.state.sequence
            scene = next(scene for scene in self.manifest.scenes if scene.scene_id == self.state.scene_id)
            validate_scene_event(scene, event)
            if event.sequence:
                return self.dispatch(event)
            if intent_index is None:
                return self.dispatch(event)
            events = self.view().events
            current = events[intent_index] if 0 <= intent_index < len(events) else None
            if current is not None and (current.scene_id, current.kind, current.key) != (event.scene_id, event.kind, event.key):
                current = None
            return self.dispatch(current) if current is not None else self.state.sequence
        finally:
            if self.state is before and self.on_change is not None:
                self.on_change(self.state.sequence)

    def key(self, key):
        action = KEY_ACTIONS.get(key.lower() if len(key) == 1 else key)
        if action:
            self.action(action)

    def sync_url(self, query_params):
        self.query_params = query_params
        fields = {key: query_params.get(key) for key in ("scene", "layer", "depth", "answer") if query_params.get(key) is not None}
        url = "?" + urlencode(fields, doseq=True) if fields else ""
        if url != self.last_url:
            restored = restore_url(self.manifest, url) if url else initial_player_state(self.manifest)
            self.state = replace(restored, sequence=self.state.sequence + 1)
            self.last_url = url

    def view(self):
        result = dispatch_renderer(self.manifest, self.state, renderers=self.renderers)
        actions = tuple(action for action, *_ in CONTROLS) + ("jump",)
        if isinstance(result, SceneError):
            return PlayerView(None, result.summary, result.recovery, actions)
        empty = result.body is None or isinstance(result.body, str) and not result.body.strip()
        warning = "Scene renderer returned an empty body; use the static fallback." if empty else self.state.warning
        scene = next(scene for scene in self.manifest.scenes if scene.scene_id == self.state.scene_id)
        return PlayerView(result.body, warning, scene.fallback if empty else None, actions, result.events)


def render_player(manifest, *, renderers=None, controller=None, query_params=None):
    """Render shell navigation first and contain a single selected scene body."""
    import marimo as mo

    player = controller or PlayerController(manifest, renderers=renderers)
    if query_params is not None:
        player.sync_url(query_params)
    state = player.state
    scene = next(scene for scene in manifest.scenes if scene.scene_id == state.scene_id)
    layer = next(layer for layer in scene.layers if layer.layer_id == state.layer_id)

    player.widgets = {}

    def wrap(action, widget):
        # Marimo's registry keeps weak references: text wrappers alone would
        # leave visible buttons whose Python callbacks were garbage-collected.
        player.widgets[action] = widget
        return mo.Html(f'<span data-player-action="{escape(action, quote=True)}">{widget.text}</span>')

    buttons = [wrap(action, mo.ui.button(
        label=label, keyboard_shortcut=shortcut,
        on_click=lambda _, action=action: player.submit_action(action),
    )) for action, label, _, shortcut in CONTROLS]
    menu = mo.ui.dropdown(
        options={f"{i + 1:02d} · {item.title}": item.scene_id for i, item in enumerate(manifest.scenes)},
        value=next(f"{i + 1:02d} · {item.title}" for i, item in enumerate(manifest.scenes) if item.scene_id == scene.scene_id),
        label="Question", on_change=lambda target: player.action("jump", scene_id=target),
    )
    index = manifest.scene_ids.index(scene.scene_id) + 1
    stage_label = {"predict": "Predict", "manipulate": "Explore",
                   "explain": "Explain", "transfer": "Apply"}.get(layer.stage.lower(), "Explore")
    stages = ("Predict", "Explore", "Explain", "Apply")
    pills = "".join(f'<span class="{"active" if name == stage_label else ""}">{name}</span>' for name in stages)
    heading = mo.Html(
        f'<header class="teaching-top" data-player-scene="{escape(scene.scene_id)}" data-player-layer="{escape(layer.layer_id)}" data-player-sequence="{state.sequence}" '
        f'data-player-transport="{player.transport_id}" data-player-action-ack="{player.action_ack}">'
        f'<h2>{escape(scene.title)}</h2>'
        f'<div class="teaching-meta"><span>Part {escape(str(scene.session))} · question {index}/{len(manifest.scenes)}</span>'
        f'<progress value="{index}" max="{len(manifest.scenes)}" aria-label="Scene progress"></progress>'
        f'<div class="stage-pills">{pills}</div></div></header>'
    )
    navigation = mo.vstack([
        mo.Html(teaching_stage_css()), heading,
        mo.hstack(buttons[:3] + [wrap("jump", menu)], wrap=True, justify="start").style({"padding": "8px 16px 2px"}),
        mo.hstack(buttons[3:], wrap=True, justify="start").style({"padding": "0 16px 8px", "opacity": ".78"}),
    ])
    view = player.view()
    player.last_view = view
    content = [navigation, mo.iframe(KEYBOARD_BRIDGE, width="0", height="0")]
    if view.warning:
        content.append(mo.callout(mo.md(
            "**Interactive view unavailable.** Please use the static figure and continue the discussion."
        ), kind="warn"))
    if view.body is not None:
        task = mo.Html(facilitation_panel_html(scene, layer.stage, "task"))
        explanation = mo.Html(facilitation_panel_html(scene, layer.stage, "explain"))
        main = mo.vstack([mo.Html('<span class="teaching-main-marker" aria-label="interactive visualization"></span>'), view.body]).style({"background": "white", "border": "1px solid #d9dde2", "border-radius": "10px", "padding": "12px 16px", "min-width": "0"})
        content.append(mo.hstack([task, main, explanation], widths=[1.05, 3.2, 1.15], align="start", wrap=True, gap=1.0))
    if view.events:
        content.append(mo.hstack([wrap(f"scene-event-{scene.scene_id}:{event.kind}:{event.key}:{index}", mo.ui.button(
            label=scene_event_label(event),
            on_click=lambda _, event=event, index=index: player.submit_scene_event(event, intent_index=index),
        )) for index, event in enumerate(view.events)], wrap=True))
    if layer.stage.lower() == "transfer":
        content.append(mo.md(scene.transfer_prompt))
    if state.answer_visible:
        content.append(mo.callout(mo.md(scene.transfer_answer), kind="info"))
    return mo.vstack(content)
