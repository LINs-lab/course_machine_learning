"""Immutable contracts consumed by the course-level lecture player."""
from dataclasses import dataclass, field
from enum import Enum
from types import MappingProxyType
from typing import Any, Callable, Mapping, Sequence

class Tier(str, Enum):
    CORE = "Core"
    DEEPENING = "Deepening"
    RESERVE = "Reserve"

def _tuple(value: Sequence[str] | None) -> tuple[str, ...]:
    return tuple(value or ())

def _freeze(value: Any) -> Any:
    if value is None or isinstance(value, (bool, int, float, str, bytes)):
        return value
    if isinstance(value, Mapping):
        return MappingProxyType({key: _freeze(item) for key, item in value.items()})
    if isinstance(value, (list, tuple)):
        return tuple(_freeze(item) for item in value)
    if isinstance(value, (set, frozenset)):
        return frozenset(_freeze(item) for item in value)
    raise TypeError(f"unsupported mutable state value: {type(value).__name__}")

@dataclass(frozen=True)
class Layer:
    layer_id: str
    stage: str
    tier: Tier
    duration: float
    action: str
    prerequisites: tuple[str, ...] = ()
    math_refs: tuple[str, ...] = ()
    central_explanation: bool = False
    next_core: str | None = None
    branches: tuple[str, ...] = ()
    next_deepening: str | None = None
    next_reserve: str | None = None
    def __post_init__(self) -> None:
        object.__setattr__(self, "prerequisites", _tuple(self.prerequisites))
        object.__setattr__(self, "math_refs", _tuple(self.math_refs))
        object.__setattr__(self, "branches", _tuple(self.branches))

@dataclass(frozen=True)
class Scene:
    scene_id: str
    title: str
    session: int | str
    target_duration: float
    slide_refs: tuple[str, ...]
    slide_claims: tuple[str, ...]
    predict_prompt: str
    transfer_prompt: str
    transfer_answer: str
    initial_state: Mapping[str, Any]
    shared_state_keys: tuple[str, ...]
    scene_state_keys: tuple[str, ...]
    state_ownership: Mapping[str, str]
    reset_scope: tuple[str, ...]
    layers: tuple[Layer, ...]
    renderer: str | Callable[..., Any]
    dependencies: tuple[str, ...] = ()
    fallback: str | None = None
    notes: str | None = None
    participation: str = "instructor"
    student_task: str = ""
    watch_for: str = ""
    say_it: str = ""
    def __post_init__(self) -> None:
        for name in ("slide_refs", "slide_claims", "shared_state_keys", "scene_state_keys", "reset_scope", "layers", "dependencies"):
            object.__setattr__(self, name, tuple(getattr(self, name) or ()))
        frozen = _freeze(self.initial_state or {})
        object.__setattr__(self, "initial_state", frozen)
        object.__setattr__(self, "state_ownership", MappingProxyType(dict(self.state_ownership or {})))

@dataclass(frozen=True)
class LectureManifest:
    scenes: tuple[Scene, ...]
    lecture_id: str = "lecture"
    def __post_init__(self) -> None:
        object.__setattr__(self, "scenes", tuple(self.scenes or ()))
    @property
    def scene_ids(self) -> tuple[str, ...]:
        return tuple(scene.scene_id for scene in self.scenes)

@dataclass(frozen=True)
class ValidationReport:
    scene_ids: tuple[str, ...]
    action_distances: Mapping[str, int]
    def __post_init__(self) -> None:
        object.__setattr__(self, "scene_ids", tuple(self.scene_ids))
        object.__setattr__(self, "action_distances", MappingProxyType(dict(self.action_distances)))


@dataclass(frozen=True)
class SceneSnapshot:
    """Complete in-memory state of a scene during one live teaching session."""

    layer_id: str
    depth: int
    answer_visible: bool
    shared_state: Mapping[str, Any]
    scene_state: Mapping[str, Any]

    def __post_init__(self) -> None:
        object.__setattr__(self, "shared_state", _freeze(self.shared_state or {}))
        object.__setattr__(self, "scene_state", _freeze(self.scene_state or {}))


@dataclass(frozen=True)
class PlayerState:
    """Immutable shell navigation plus the selected scene's declared controls."""

    scene_id: str
    layer_id: str
    depth: int = 0
    answer_visible: bool = False
    shared_state: Mapping[str, Any] = field(default_factory=dict)
    scene_state: Mapping[str, Any] = field(default_factory=dict)
    snapshots: Mapping[str, SceneSnapshot] = field(default_factory=dict)
    sequence: int = 0
    warning: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "shared_state", _freeze(self.shared_state or {}))
        object.__setattr__(self, "scene_state", _freeze(self.scene_state or {}))
        snapshots = dict(self.snapshots or {})
        if any(not isinstance(snapshot, SceneSnapshot) for snapshot in snapshots.values()):
            raise TypeError("snapshots must contain SceneSnapshot values")
        object.__setattr__(self, "snapshots", MappingProxyType(snapshots))


@dataclass(frozen=True)
class StateEvent:
    """A sequenced, declarative request applied by the course-player reducer."""

    kind: str
    sequence: int = 0
    scene_id: str | None = None
    layer_id: str | None = None
    key: str | None = None
    value: Any = None
    label: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "value", _freeze(self.value))


@dataclass(frozen=True)
class SceneResult:
    """Successful lazy scene-render result; the shell owns all navigation UI."""

    body: Any
    events: tuple[StateEvent, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "events", tuple(self.events or ()))


@dataclass(frozen=True)
class SceneError:
    """Bounded renderer failure that leaves shell navigation available."""

    scene_id: str
    summary: str
    recovery: str
