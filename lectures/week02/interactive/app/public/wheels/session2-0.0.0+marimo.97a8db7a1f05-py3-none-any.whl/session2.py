"""S07–S12: half-MSE local geometry, deterministic GD, and exact batch clouds.

All controls are declarative intents. The shell assigns their sequence at dispatch.
Feature scaling changes coordinates, keeping the initial fitted line unchanged.
"""
from dataclasses import dataclass, replace
from html import escape
from textwrap import fill

import numpy as np
from matplotlib.figure import Figure

from course_player import SceneResult, StateEvent
from public.model import (batch_gradient_summary, design_matrix, gd_path,
                          gradient_mse, hessian_half_mse, objective)
from session1 import BASE_X, BASE_Y, Control
from visuals import COLORS, figure_svg

SHARED_PRESET = {"s2.x": BASE_X, "s2.y": BASE_Y, "s2.gamma": .5}
LOCAL_PRESET = {"steps": 0, "delta": .5, "direction": "descent", "scale": 1., "batch": 1, "case": "conditioning"}


def scene_presets(scene_id):
    """S10 owns its rate because its authored feature units differ from S09."""
    shared, local = dict(SHARED_PRESET), dict(LOCAL_PRESET)
    if scene_id == "L02-S10":
        del shared["s2.gamma"]
        local.update(scale=4., steps=6, **{"s2.gamma": .05})
    return shared, local

ANNOTATIONS = {
    "L02-S07-objective": r"Canonical half-MSE: $J(w)=\|y-Xw\|^2/(2N)=\mathrm{MSE}/2$, $\nabla J=X^T(Xw-y)/N$. We keep this normalization throughout Session 2.",
    "L02-S07-local": r"For a small perturbation $\delta$, $J(w+\delta)\approx J(w)+\nabla J(w)^T\delta$. For this quadratic the exact remainder is $\delta^T H\delta/2$: halving the perturbation quarters the remainder.",
    "L02-S08-objective": r"$J=\|y-Xw\|^2/(2N)$ and $g=\nabla J=X^T(Xw-y)/N$ use the same eight observations in all views.",
    "L02-S08-update": r"$w^+=w-\gamma g$; $\hat y^+=Xw^+=\hat y-\gamma Xg$; $J(w^+)=\|y-\hat y^+\|^2/(2N)$. Blue is the current iterate; red is the next iterate in every panel.",
    "L02-S09-hessian": r"For $J=\|y-Xw\|^2/(2N)$, $H=\nabla^2J=X^TX/N$. With full column rank, $H$ is positive definite. $Hv_j=\lambda_jv_j$: $J(w^*+tv_j)=J(w^*)+\lambda_jt^2/2$.",
    "L02-S09-stability": r"Writing $a_{j,k}=v_j^T(w_k-w^*)$ gives $a_{j,k+1}=(1-\gamma\lambda_j)a_{j,k}$. Every mode contracts exactly when $0<\gamma<2/\lambda_{\max}$. At equality the largest mode flips sign without decay; above it a nonzero largest-mode component grows. An absent component does not spontaneously appear.",
    "L02-S09-directions": r"Eigenvectors are unoriented axes: $v$ and $-v$ describe the same curvature. When the eigenvalues coincide, every orthonormal basis is valid; there is no distinguished principal direction.",
    "L02-S10-conditioning": r"$\kappa(H)=\lambda_{\max}/\lambda_{\min}$. A step near the upper stability limit flips the stiff mode while the flatter mode contracts slowly: a zig-zag path. The best constant step for this SPD quadratic is $2/(\lambda_{\min}+\lambda_{\max})$, with worst-mode contraction $(\kappa-1)/(\kappa+1)$.",
    "L02-S10-normalization": r"Set $z=(sx-\mu)/\sigma$. The same prediction uses $\theta_0=w_0+\mu w_1$, $\theta_1=\sigma w_1$. Here $Z^TZ/N=I$, so centering and scaling remove unequal curvature. Compare both paths at $\gamma=0.9(2/\lambda_{\max})$ of their own Hessian; coordinate scales and step sizes differ.",
    "L02-S11-cloud": r"At a fixed $w$, $g_i=x_i^{\rm aug}(x_i^{{\rm aug}T}w-y_i)$ and $g_B=B^{-1}\sum_{i\in B}g_i$. We enumerate all equally likely subsets of size $B$ without replacement: $E[g_B]=g$. The cloud shows endpoints, not one selected random arrow.",
    "L02-S11-dispersion": r"With $S=\sum_i(g_i-g)(g_i-g)^T$, $\operatorname{Cov}(g_B)=(N-B)S/[BN(N-1)]$. Thus $E\|g_B-g\|^2=\operatorname{tr}\operatorname{Cov}(g_B)$, and $B=N$ has zero sampling variance. This finite-population law is not a universal exact $1/B$ law; variance alone says nothing about wall-clock speed or generalization.",
    "L02-S12-diagnosis": r"Diagnose separately: a step beyond $2/\lambda_{\max}$ causes unstable curvature modes; unequal curvature motivates normalization/preconditioning; a small batch creates sampling variance. A bigger batch does not repair a full-gradient stability violation.",
}

TRANSFER_CASES = {
    "conditioning": {"prompt": "New case: a feature is recorded in units four times larger; full-batch GD zig-zags. Would a bigger batch solve this?", "answer": "No: it already uses the full batch. Inspect the Hessian spectrum, choose a stable rate for the new units, and normalize or precondition to reduce unequal contraction.", "scale": 4., "ratio": .9, "batch": 8},
    "sampling": {"prompt": "New case: well-scaled features and a stable rate, but single-sample gradients scatter widely. What should a larger batch change?", "answer": "A larger uniform batch without replacement reduces the displayed gradient variance; full batch removes sampling variance. This alone does not guarantee faster wall-clock training or better generalization.", "scale": 1., "ratio": .5, "batch": 1},
    "instability": {"prompt": "New case: full-batch GD grows after the rate crosses 2/lambda_max. Would averaging more gradients fix it?", "answer": "No: there is no batch sampling noise to remove. Reduce gamma below the stability boundary; a nonzero stiff-mode component grows above that boundary.", "scale": 1., "ratio": 1.1, "batch": 8},
}


@dataclass(frozen=True)
class SceneData:
    x: np.ndarray
    y: np.ndarray
    design: np.ndarray
    initial_weights: np.ndarray
    weights: np.ndarray
    next_weights: np.ndarray
    prediction: np.ndarray
    next_prediction: np.ndarray
    gradient: np.ndarray
    hessian: np.ndarray
    eigenvalues: np.ndarray
    eigenvectors: np.ndarray
    optimum: np.ndarray
    objective: float
    next_objective: float
    path: np.ndarray
    losses: np.ndarray
    gamma: float
    limit: float
    stability: str
    factors: np.ndarray
    condition: float
    isotropic: bool
    perturbation: np.ndarray
    local_linear: float
    local_actual: float
    cloud: object
    normalized_design: np.ndarray
    normalized_initial: np.ndarray
    normalized_path: np.ndarray
    normalized_losses: np.ndarray
    normalized_condition: float
    comparison_losses: np.ndarray
    scale: float
    steps: int
    batch: int


def scene_data(state):
    def invalid(message):
        raise ValueError(f"{state.scene_id}: {message}")
    shared_preset, local_preset = scene_presets(state.scene_id)
    if set(state.shared_state) != set(shared_preset) or set(state.scene_state) != set(local_preset):
        invalid("missing or undeclared control key")
    shared, local = state.shared_state, state.scene_state
    gamma = local["s2.gamma"] if "s2.gamma" in local else shared["s2.gamma"]
    try:
        x, y = np.asarray(shared["s2.x"], dtype=float), np.asarray(shared["s2.y"], dtype=float)
    except (TypeError, ValueError):
        invalid("dataset must contain numeric values")
    if x.shape != (8,) or y.shape != (8,) or not np.isfinite(x).all() or not np.isfinite(y).all() or max(np.max(np.abs(x)), np.max(np.abs(y))) > 100:
        invalid("expected eight finite observations bounded by 100")
    for key, value, low, high in (("gamma", gamma, 0, 10), ("scale", local["scale"], 0, 4), ("delta", local["delta"], 0, 2)):
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not np.isfinite(value) or not low < value <= high:
            invalid(f"{key} must be finite and in ({low},{high}]")
    for key, low, high in (("steps", 0, 12), ("batch", 1, 8)):
        if isinstance(local[key], bool) or not isinstance(local[key], int) or not low <= local[key] <= high:
            invalid(f"{key} must be an integer in [{low},{high}]")
    if local["direction"] not in ("descent", "intercept", "slope") or local["case"] not in TRANSFER_CASES:
        invalid("unknown direction or transfer case")
    scale, batch = local["scale"], local["batch"]
    if state.scene_id == "L02-S12":
        case = TRANSFER_CASES[local["case"]]
        scale, batch = case["scale"], case["batch"]
    X = design_matrix(scale * x)
    H = hessian_half_mse(X)
    if H.shape != (2, 2) or not np.isfinite(H).all() or not np.allclose(H, H.T, rtol=0, atol=1e-12):
        invalid("Hessian must be finite symmetric 2 by 2")
    eigenvalues, vectors = np.linalg.eigh(H)
    if eigenvalues[0] <= 1e-10:
        invalid("Hessian must be positive definite for this full-rank scene")
    # Fix only sign for deterministic rendering; isotropic bases are not unique.
    vectors = vectors.copy()
    for col in range(2):
        if vectors[np.argmax(np.abs(vectors[:, col])), col] < 0:
            vectors[:, col] *= -1
    limit = 2 / eigenvalues[-1]
    if state.scene_id == "L02-S12":
        gamma = case["ratio"] * limit
    stability = "boundary" if gamma == limit else ("stable" if gamma < limit else "unstable")
    initial = np.array([0., .5 / scale])
    optimum = np.linalg.lstsq(X, y, rcond=None)[0]
    steps = local["steps"]
    path = gd_path(X, y, initial, learning_rate=gamma, steps=max(steps + 1, 12))
    w = path[steps]
    g = gradient_mse(X, y, w)
    direction = {"descent": -g / max(np.linalg.norm(g), 1e-15), "intercept": np.array([1., 0.]), "slope": np.array([0., 1.])}[local["direction"]]
    perturbation = local["delta"] * direction
    loss = objective(X, y, w)
    mean, std = float(np.mean(scale * x)), float(np.std(scale * x))
    Z = design_matrix((scale * x - mean) / std)
    theta = np.array([initial[0] + mean * initial[1], std * initial[1]])
    normalized_eigenvalues = np.linalg.eigvalsh(hessian_half_mse(Z))
    normalized_path = gd_path(Z, y, theta, learning_rate=.9 * 2 / normalized_eigenvalues[-1], steps=12)
    comparison = gd_path(X, y, initial, learning_rate=.9 * limit, steps=12)
    return SceneData(x, y, X, initial, w, path[steps + 1], X @ w, X @ path[steps + 1], g, H,
                     eigenvalues, vectors, optimum, loss, objective(X, y, path[steps + 1]), path,
                     np.array([objective(X, y, point) for point in path]), gamma, limit, stability,
                     1 - gamma * eigenvalues, float(eigenvalues[-1] / eigenvalues[0]),
                     bool(np.isclose(eigenvalues[0], eigenvalues[-1], rtol=1e-10, atol=1e-12)),
                     perturbation, loss + g @ perturbation, objective(X, y, w + perturbation),
                     batch_gradient_summary(X, y, w, batch_size=batch), Z, theta, normalized_path,
                     np.array([objective(Z, y, point) for point in normalized_path]),
                     float(normalized_eigenvalues[-1] / normalized_eigenvalues[0]),
                     np.array([objective(X, y, point) for point in comparison]), scale, steps, batch)


def controls_for(state, data=None):
    data = data or scene_data(state)
    return _controls(state.scene_id, data.limit)


def _controls(sid, limit):
    refs = {
        "L02-S07": "local", "L02-S08": "update", "L02-S09": "stability",
        "L02-S10": "conditioning", "L02-S11": "cloud", "L02-S12": "diagnosis",
    }
    ref = (f"{sid}-{refs[sid]}",)
    step = Control("steps", "current GD step k", tuple(range(13)), ref)
    rate = Control("s2.gamma", "learning rate gamma (half-MSE)", (.5 * limit, limit, 1.1 * limit, .9 * limit), ref)
    if sid == "L02-S07":
        return (Control("delta", "perturbation length", (.5, .25, .125, 1.), ref), Control("direction", "perturbation direction", ("descent", "intercept", "slope"), ref))
    if sid in ("L02-S08", "L02-S09"):
        return (step, rate)
    if sid == "L02-S10":
        return (step, rate, Control("scale", "feature units multiplier", (1., 4., 2.), ref))
    if sid == "L02-S11":
        return (Control("batch", "uniform batch size B", (1, 2, 4, 8), ref), step)
    return (Control("case", "new optimization situation", tuple(TRANSFER_CASES), ref),)


def validate_scene_contract(scene):
    for layer in scene.layers:
        if not layer.math_refs or any(ref not in ANNOTATIONS for ref in layer.math_refs):
            raise ValueError(f"{scene.scene_id}: undeclared formula annotation")
    # Key and formula ownership is structural; never solve an unselected scene.
    for control in _controls(scene.scene_id, 1.):
        if control.key not in scene.state_ownership or not control.math_refs or any(ref not in scene.slide_claims for ref in control.math_refs):
            raise ValueError(f"{scene.scene_id}: undeclared control or math reference {control.key}")


def _contour(ax, data, *, trajectory=True):
    visible = data.path[:data.steps + 2] if trajectory else np.array([data.initial_weights, data.optimum])
    lower = np.minimum(visible.min(axis=0), data.optimum) - .4
    upper = np.maximum(visible.max(axis=0), data.optimum) + .4
    a, b = np.meshgrid(np.linspace(lower[0], upper[0], 80), np.linspace(lower[1], upper[1], 80))
    points = np.stack([a - data.optimum[0], b - data.optimum[1]], axis=-1)
    values = .5 * np.einsum("...i,ij,...j->...", points, data.hessian, points)
    ax.contour(a, b, values, levels=10, colors="#b0bbc3", linewidths=.8)
    ax.scatter(*data.optimum, marker="*", s=130, color=COLORS["residual"], label="optimum")
    if trajectory:
        ax.plot(*visible.T, "o-", color=COLORS["mse"], markersize=4)
        ax.scatter(*data.weights, color=COLORS["mse"], s=80, label="current w")
        ax.scatter(*data.next_weights, color=COLORS["selected"], s=80, label="next w+")
    ax.set(xlabel="intercept w0", ylabel="coefficient w1 of scaled x")
    ax.legend(fontsize=9)


def scene_figure(scene_id, data, *, stage="explain", normalization=False):
    fig = Figure(figsize=(14, 5), layout="constrained")
    if stage == "predict":
        ax = fig.subplots()
        ax.scatter(data.x, data.y, color=COLORS["data"], label="eight observations")
        ax.plot(data.x, data.prediction, color=COLORS["mse"], label="current rule")
        ax.set(xlabel="original input x", ylabel="response y", title="Predict the effect before revealing the dynamics")
        ax.legend()
        return fig
    axes = fig.subplots(1, 3 if scene_id == "L02-S08" else 2)
    if scene_id == "L02-S07":
        t = np.linspace(-1.2, 1.2, 101)
        actual = [objective(data.design, data.y, data.weights + value * data.perturbation) for value in t]
        axes[0].plot(t, actual, color=COLORS["mse"], label="exact J(w+t delta)")
        axes[0].plot(t, data.objective + t * (data.gradient @ data.perturbation), "--", color=COLORS["selected"], label="local linear prediction")
        axes[0].scatter([1], [data.local_actual], color=COLORS["mse"])
        axes[0].scatter([1], [data.local_linear], color=COLORS["selected"])
        axes[0].set(xlabel="multiple t of perturbation delta", ylabel="half-MSE J", title="Tangent before the update rule")
        axes[0].legend(fontsize=10)
        _contour(axes[1], data, trajectory=False)
        axes[1].quiver(*data.weights, *data.perturbation, angles="xy", scale_units="xy", scale=1, color=COLORS["selected"])
        axes[1].set_title(f"delta^T H delta / 2 = {data.local_actual-data.local_linear:.4g}")
    elif scene_id == "L02-S08":
        axes[0].scatter(data.x, data.y, color=COLORS["data"])
        axes[0].plot(data.x, data.prediction, color=COLORS["mse"], label="current prediction")
        axes[0].plot(data.x, data.next_prediction, color=COLORS["selected"], label="next prediction")
        axes[0].set(xlabel="original input x", ylabel="response y", title=f"Data space: step {data.steps} to {data.steps+1}")
        axes[0].legend(fontsize=9)
        _contour(axes[1], data)
        axes[1].set_title("Parameter space: w+ = w - gamma g")
        axes[2].plot(np.arange(data.steps + 2), data.losses[:data.steps + 2], "o-", color=COLORS["mse"])
        axes[2].scatter([data.steps + 1], [data.next_objective], color=COLORS["selected"], s=70)
        axes[2].set(xlabel="GD step k", ylabel="half-MSE J", title=f"Loss space: {data.objective:.3g} to {data.next_objective:.3g}")
    elif scene_id == "L02-S09":
        _contour(axes[0], data, trajectory=False)
        radius = .65
        for col, color in enumerate((COLORS["residual"], COLORS["selected"])):
            ends = data.optimum[:, None] + radius * data.eigenvectors[:, col, None] * np.array([-1., 1.])
            axes[0].plot(*ends, color=color, linewidth=3, label=f"lambda{col+1}={data.eigenvalues[col]:.3g}")
        axes[0].legend(fontsize=9)
        axes[0].set_aspect("equal", adjustable="datalim")
        axes[0].set_title("Isotropic: every orthonormal basis is valid" if data.isotropic else "Unoriented principal curvature axes")
        t = np.linspace(-1, 1, 101)
        for col, color in enumerate((COLORS["residual"], COLORS["selected"])):
            axes[1].plot(t, .5 * data.eigenvalues[col] * t*t, color=color, label=f"along v{col+1}")
        axes[1].set(xlabel="distance t from optimum along unit eigenvector", ylabel="J(w*+t v) - J(w*)", title=f"gamma={data.gamma:.4g}; 2/lambda_max={data.limit:.4g}: {data.stability}")
        axes[1].legend(fontsize=10)
    elif normalization:
        axes[0].bar(["original units", "centered + scaled"], [data.condition, data.normalized_condition], color=[COLORS["selected"], COLORS["residual"]])
        axes[0].set(ylabel="Hessian condition number", title="Equivalent predictions; different coordinates")
        axes[1].semilogy(data.comparison_losses, "o-", color=COLORS["selected"], label="original units")
        axes[1].semilogy(data.normalized_losses, "o-", color=COLORS["residual"], label="centered + scaled")
        axes[1].set(xlabel="GD step", ylabel="half-MSE J", title="Each rate = 0.9 of its own stability limit")
        axes[1].legend(fontsize=10)
    elif scene_id in ("L02-S10", "L02-S12"):
        _contour(axes[0], data)
        axes[0].set_title(f"Feature scale={data.scale:g}; kappa(H)={data.condition:.3g}")
        coordinates = (data.path - data.optimum) @ data.eigenvectors
        for col, color in enumerate((COLORS["residual"], COLORS["selected"])):
            axes[1].plot(coordinates[:, col], "o-", color=color, label=f"mode {col+1}: factor {data.factors[col]:.3g}")
        axes[1].axhline(0, color="#999999", linewidth=.7)
        axes[1].set(xlabel="GD step k", ylabel="v_j^T (w_k - w*)", title="Unequal contraction and sign flips")
        axes[1].legend(fontsize=10)
        if scene_id == "L02-S12" and data.batch == 1:
            axes[1].clear()
            _cloud(axes[1], data)
    else:
        _cloud(axes[0], data)
        dispersion = [batch_gradient_summary(data.design, data.y, data.weights, batch_size=batch).expected_squared_error for batch in range(1, 9)]
        axes[1].plot(range(1, 9), dispersion, "o-", color=COLORS["residual"])
        axes[1].scatter([data.batch], [data.cloud.expected_squared_error], color=COLORS["selected"], s=90)
        axes[1].set(xlabel="uniform batch size B without replacement", ylabel="E ||g_B - g|| squared", title="Exact dispersion across ALL fixed-size subsets")
        axes[1].set_xticks(range(1, 9))
    for ax in axes:
        ax.grid(alpha=.16)
        ax.tick_params(labelsize=10)
    return fig


def _cloud(ax, data):
    ax.scatter(*data.cloud.gradients.T, alpha=.65, color=COLORS["residual"], label=f"all {len(data.cloud.gradients)} batch gradients")
    ax.scatter(*data.gradient, color=COLORS["selected"], marker="*", s=180, label="full gradient = cloud mean")
    ax.set(xlabel="gradient component g0", ylabel="gradient component g1", title=f"B={data.batch}, N=8; E||g_B-g||^2={data.cloud.expected_squared_error:.4g}")
    ax.legend(fontsize=9)


def render_scene(state):
    import marimo as mo
    from manifest import MANIFEST
    scene = next(scene for scene in MANIFEST.scenes if scene.scene_id == state.scene_id)
    layer = next(layer for layer in scene.layers if layer.layer_id == state.layer_id)
    data = scene_data(state)
    figure = scene_figure(state.scene_id, data, stage=layer.stage, normalization=state.layer_id == "normalization")
    body = [mo.Html(f'<article data-scene="{escape(state.scene_id)}" data-visual-stage="{escape(layer.stage)}" data-render-sequence="{state.sequence}"></article>'), mo.Html(figure_svg(figure))]
    refs, events = [], []
    if layer.stage != "predict":
        for control in controls_for(state, data):
            value = {**state.shared_state, **state.scene_state}[control.key]
            index = control.values.index(value) if value in control.values else -1
            following = control.values[(index + 1) % len(control.values)]
            body.append(mo.md(f"**{control.label}:** {value} → {following} on Apply `{control.key}`."))
            if layer.stage in ("explain", "transfer"):
                refs.extend(control.math_refs)
            events.append(StateEvent("write", scene_id=state.scene_id, key=control.key, value=following, label=control.label))
        body.append(mo.md(f"Half-MSE: J={data.objective:.6g}; gradient=({data.gradient[0]:.5g}, {data.gradient[1]:.5g}); gamma={data.gamma:.6g}; stability limit={data.limit:.6g}; **{data.stability}**. Current step k={data.steps}."))
        if layer.stage in ("explain", "transfer"):
            if state.scene_id == "L02-S10":
                body.append(mo.md("The scaled-feature experiment starts with its own rate, gamma=0.05. Rate changes stay with this experiment."))
            if state.scene_id in ("L02-S09", "L02-S10"):
                body.append(mo.md(f"Hessian eigenvalues = ({data.eigenvalues[0]:.6g}, {data.eigenvalues[1]:.6g}); mode factors = ({data.factors[0]:.6g}, {data.factors[1]:.6g})."))
                if data.isotropic:
                    body.append(mo.md("Isotropic Hessian: no distinguished principal direction; any orthonormal basis is valid."))
    if layer.stage in ("explain", "transfer"):
        refs.extend(layer.math_refs)
    body.extend(mo.md(ANNOTATIONS[ref]) for ref in dict.fromkeys(refs))
    if state.scene_id == "L02-S12":
        case = TRANSFER_CASES[state.scene_state["case"]]
        body.append(mo.md(case["prompt"]))
        if state.answer_visible:
            body.append(mo.callout(mo.md(case["answer"]), kind="info"))
    return SceneResult(mo.vstack(body), tuple(events))


def fallback_svg(scene):
    from course_player import LectureManifest, initial_player_state
    state = initial_player_state(LectureManifest((scene,)))
    if scene.scene_id in ("L02-S08", "L02-S10", "L02-S12"):
        scale = 4. if scene.scene_id in ("L02-S10", "L02-S12") else 1.
        state = replace(state, scene_state={**state.scene_state, "steps": 6 if scale == 4 else 0, "scale": scale})
        rate_state = "scene_state" if "s2.gamma" in state.scene_state else "shared_state"
        state = replace(state, **{rate_state: {**getattr(state, rate_state), "s2.gamma": .9 * scene_data(state).limit}})
    data = scene_data(state)
    conclusions = {
        "L02-S07": "The gradient gives the local linear change. The exact quadratic error is delta^T H delta / 2, so halving delta quarters the approximation error.",
        "L02-S08": "One update changes the parameter point, fitted line, and half-MSE together: w+ = w - gamma g; prediction+ = Xw+; J+ = ||y-Xw+|| squared / (2N). Blue is current; red is next.",
        "L02-S09": "For J=||y-Xw|| squared /(2N), H=X^T X/N. Its eigenvectors are unoriented curvature axes. Each mode multiplies by 1-gamma lambda. Stable: 0<gamma<2/lambda_max; equality flips the stiff mode without decay; above it a nonzero stiff mode grows.",
        "L02-S10": "Unequal eigenvalues mean unequal contraction. Near the stability limit the stiff mode flips while the flat mode decays slowly, producing zig-zags. Increasing batch size cannot repair this full-gradient conditioning problem.",
        "L02-S11": "Every subset of size B is equally likely, sampled without replacement. Cloud mean = full gradient. Cov(g_B)=(N-B) sum_i (g_i-g)(g_i-g)^T / [BN(N-1)]; B=N has zero sampling variance. No universal exact 1/B law is claimed.",
        "L02-S12": TRANSFER_CASES["conditioning"]["answer"],
    }
    figure = scene_figure(scene.scene_id, data)
    figure.set_size_inches(14, 7)
    figure.set_layout_engine(None)
    figure.subplots_adjust(top=.76, bottom=.31, left=.08, right=.97, wspace=.4)
    figure.text(.035, .965, scene.title, fontsize=19, va="top")
    figure.text(.035, .90, fill(scene.predict_prompt, 110), fontsize=14, va="top")
    if scene.scene_id == "L02-S12":
        figure.subplots_adjust(top=.68)
        figure.text(.035, .82, fill(TRANSFER_CASES["conditioning"]["prompt"], 125), fontsize=12, va="top")
    figure.text(.035, .18, fill("Conclusion: " + conclusions[scene.scene_id], 126), fontsize=13, va="top")
    return figure_svg(figure)
